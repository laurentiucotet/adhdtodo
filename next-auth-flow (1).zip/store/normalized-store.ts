"use client"

import { create } from "zustand"
import type { Task } from "@/types"
import type { Tag } from "@/hooks/use-tags"

// Normalized state structure
interface NormalizedState {
  // Entities
  tasks: Record<string, Task>
  tags: Record<string, Tag>
  taskTags: Record<string, string[]> // taskId -> tagIds[]

  // Indexes
  taskIds: string[]
  tagIds: string[]

  // UI state
  selectedTagIds: string[]
  showCompleted: boolean

  // Loading states
  loading: boolean
  error: string | null

  // Actions
  setTasks: (tasks: Task[]) => void
  setTags: (tags: Tag[]) => void
  setTaskTags: (taskId: string, tagIds: string[]) => void
  setTaskTagsBatch: (taskTagsMap: Record<string, string[]>) => void
  addTask: (task: Task) => void
  updateTask: (taskId: string, updates: Partial<Task>) => void
  removeTask: (taskId: string) => void
  toggleTaskCompletion: (taskId: string) => void
  selectTag: (tagId: string) => void
  deselectTag: (tagId: string) => void
  clearSelectedTags: () => void
  setShowCompleted: (show: boolean) => void
  setLoading: (loading: boolean) => void
  setError: (error: string | null) => void
}

export const useNormalizedStore = create<NormalizedState>((set) => ({
  // Initial state
  tasks: {},
  tags: {},
  taskTags: {}, // Initialize as empty object
  taskIds: [],
  tagIds: [],
  selectedTagIds: [],
  showCompleted: true,
  loading: false,
  error: null,

  // Actions
  setTasks: (tasks) =>
    set((state) => {
      const newTasks: Record<string, Task> = {}
      const newTaskIds: string[] = []

      tasks.forEach((task) => {
        newTasks[task.id] = task
        if (!newTaskIds.includes(task.id)) {
          newTaskIds.push(task.id)
        }
      })

      return {
        tasks: { ...state.tasks, ...newTasks },
        taskIds: newTaskIds,
      }
    }),

  setTags: (tags) =>
    set((state) => {
      const newTags: Record<string, Tag> = {}
      const newTagIds: string[] = []

      tags.forEach((tag) => {
        newTags[tag.id] = tag
        if (!newTagIds.includes(tag.id)) {
          newTagIds.push(tag.id)
        }
      })

      return {
        tags: { ...state.tags, ...newTags },
        tagIds: newTagIds,
      }
    }),

  setTaskTags: (taskId, tagIds) =>
    set((state) => ({
      taskTags: {
        ...state.taskTags,
        [taskId]: tagIds,
      },
    })),

  setTaskTagsBatch: (taskTagsMap) =>
    set((state) => ({
      taskTags: {
        ...state.taskTags,
        ...taskTagsMap,
      },
    })),

  addTask: (task) =>
    set((state) => {
      // Add task to normalized state
      const newTasks = { ...state.tasks, [task.id]: task }

      // Add task ID to the beginning of the list (for newest first)
      const newTaskIds = [task.id, ...state.taskIds]

      return {
        tasks: newTasks,
        taskIds: newTaskIds,
      }
    }),

  updateTask: (taskId, updates) =>
    set((state) => {
      // Only update if task exists
      if (!state.tasks[taskId]) return state

      // Update task
      const updatedTask = {
        ...state.tasks[taskId],
        ...updates,
      }

      return {
        tasks: {
          ...state.tasks,
          [taskId]: updatedTask,
        },
      }
    }),

  removeTask: (taskId) =>
    set((state) => {
      // Create a copy of tasks without the removed task
      const { [taskId]: removedTask, ...remainingTasks } = state.tasks

      // Remove task ID from list
      const newTaskIds = state.taskIds.filter((id) => id !== taskId)

      // Remove task tags
      const { [taskId]: removedTaskTags, ...remainingTaskTags } = state.taskTags

      return {
        tasks: remainingTasks,
        taskIds: newTaskIds,
        taskTags: remainingTaskTags,
      }
    }),

  toggleTaskCompletion: (taskId) =>
    set((state) => {
      // Only update if task exists
      if (!state.tasks[taskId]) return state

      // Toggle completion status
      const updatedTask = {
        ...state.tasks[taskId],
        completed: !state.tasks[taskId].completed,
      }

      return {
        tasks: {
          ...state.tasks,
          [taskId]: updatedTask,
        },
      }
    }),

  selectTag: (tagId) =>
    set((state) => {
      if (state.selectedTagIds.includes(tagId)) return state

      return {
        selectedTagIds: [...state.selectedTagIds, tagId],
      }
    }),

  deselectTag: (tagId) =>
    set((state) => ({
      selectedTagIds: state.selectedTagIds.filter((id) => id !== tagId),
    })),

  clearSelectedTags: () => set({ selectedTagIds: [] }),

  setShowCompleted: (show) => set({ showCompleted: show }),

  setLoading: (loading) => set({ loading }),

  setError: (error) => set({ error }),
}))

