import Link from "next/link"

export function Footer() {
  return (
    <footer className="w-full border-t bg-background py-4">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <p className="text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Next.js Auth Flow. All rights reserved.
        </p>
        <nav className="flex gap-4 sm:gap-6">
          <Link href="#" className="text-sm text-primary hover:underline underline-offset-4">
            About
          </Link>
          <Link href="#" className="text-sm text-primary hover:underline underline-offset-4">
            Privacy
          </Link>
          <Link href="#" className="text-sm text-primary hover:underline underline-offset-4">
            Terms
          </Link>
          <Link href="#" className="text-sm text-primary hover:underline underline-offset-4">
            Contact
          </Link>
        </nav>
      </div>
    </footer>
  )
}

