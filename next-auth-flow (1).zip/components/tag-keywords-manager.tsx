"use client"

import type React from "react"

import { useState } from "react"
import { useTagKeywords } from "@/hooks/use-tag-keywords"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Loader2, Plus, Pencil, Trash2, X, Check } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface TagKeywordsManagerProps {
  tagId: string
  tagName: string
  tagColor: string
}

export function TagKeywordsManager({ tagId, tagName, tagColor }: TagKeywordsManagerProps) {
  const { keywords, loading, error, addKeyword, updateKeyword, deleteKeyword } = useTagKeywords(tagId)
  const [newKeyword, setNewKeyword] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [editingKeywordId, setEditingKeywordId] = useState<string | null>(null)
  const [editKeywordValue, setEditKeywordValue] = useState("")

  // Add a new keyword
  const handleAddKeyword = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newKeyword.trim() === "") return

    setIsSubmitting(true)
    try {
      await addKeyword(tagId, newKeyword)
      setNewKeyword("") // Clear the input field
    } finally {
      setIsSubmitting(false)
    }
  }

  // Start editing a keyword
  const startEditingKeyword = (keywordId: string, currentValue: string) => {
    setEditingKeywordId(keywordId)
    setEditKeywordValue(currentValue)
  }

  // Cancel editing
  const cancelEditingKeyword = () => {
    setEditingKeywordId(null)
    setEditKeywordValue("")
  }

  // Save edited keyword
  const saveEditedKeyword = async (keywordId: string) => {
    if (editKeywordValue.trim() === "") return

    setIsSubmitting(true)
    try {
      await updateKeyword(keywordId, editKeywordValue)
      cancelEditingKeyword()
    } finally {
      setIsSubmitting(false)
    }
  }

  // Delete a keyword
  const handleDeleteKeyword = async (keywordId: string) => {
    await deleteKeyword(keywordId)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <h4 className="text-sm font-medium">Keywords for</h4>
        <Badge style={{ backgroundColor: tagColor, color: "white" }}>{tagName}</Badge>
      </div>

      <form onSubmit={handleAddKeyword} className="flex gap-2">
        <Input
          placeholder="Add keyword..."
          value={newKeyword}
          onChange={(e) => setNewKeyword(e.target.value)}
          className="rounded-xl flex-1 text-sm"
          disabled={isSubmitting}
        />
        <Button
          type="submit"
          size="sm"
          className="flex items-center gap-1"
          disabled={isSubmitting || newKeyword.trim() === ""}
        >
          {isSubmitting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
          <span>Add</span>
        </Button>
      </form>

      {error && <p className="text-sm text-destructive">{error}</p>}

      <div className="space-y-2">
        {loading ? (
          <div className="flex justify-center items-center py-2">
            <Loader2 className="h-4 w-4 animate-spin text-primary/70" />
          </div>
        ) : keywords.length === 0 ? (
          <p className="text-xs text-muted-foreground">
            No keywords yet. Add keywords to automatically tag tasks containing these words.
          </p>
        ) : (
          <ul className="space-y-2">
            {keywords.map((keyword) => (
              <li key={keyword.id} className="flex items-center justify-between bg-background rounded-lg p-2 text-sm">
                {editingKeywordId === keyword.id ? (
                  <div className="flex items-center gap-2 w-full">
                    <Input
                      value={editKeywordValue}
                      onChange={(e) => setEditKeywordValue(e.target.value)}
                      className="rounded-xl flex-1 h-8 text-sm"
                      disabled={isSubmitting}
                    />
                    <div className="flex gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={cancelEditingKeyword}
                        disabled={isSubmitting}
                        className="h-7 w-7"
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Cancel</span>
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => saveEditedKeyword(keyword.id)}
                        disabled={isSubmitting || editKeywordValue.trim() === ""}
                        className="h-7 w-7"
                      >
                        {isSubmitting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                        <span className="sr-only">Save</span>
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <span className="font-medium">{keyword.keyword}</span>
                    <div className="flex gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => startEditingKeyword(keyword.id, keyword.keyword)}
                        className="h-7 w-7"
                      >
                        <Pencil className="h-3 w-3" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDeleteKeyword(keyword.id)}
                        className="h-7 w-7"
                      >
                        <Trash2 className="h-3 w-3 text-destructive" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

