"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"

// Color name mapping for better user experience
const COLOR_NAMES: Record<string, string> = {
  "#FF5252": "Red",
  "#FF7043": "Orange",
  "#FFCA28": "Yellow",
  "#66BB6A": "Green",
  "#42A5F5": "Blue",
  "#7E57C2": "Purple",
  "#EC407A": "Pink",
  "#78909C": "Gray",
  "#26A69A": "Teal",
  "#5C6BC0": "Indigo",
}

// Default color
const DEFAULT_COLOR = "#42A5F5"

// Predefined vibrant colors to ensure visual distinction
const VIBRANT_COLORS = [
  "#FF5252",
  "#FF7043",
  "#FFCA28",
  "#66BB6A",
  "#42A5F5",
  "#7E57C2",
  "#EC407A",
  "#78909C",
  "#26A69A",
  "#5C6BC0",
  "#AB47BC",
  "#EF5350",
  "#FFA726",
  "#FFEE58",
  "#9CCC65",
  "#29B6F6",
]

interface ColorPickerProps {
  value: string
  onChange: (color: string) => void
  className?: string
  disabled?: boolean
}

export function ColorPicker({ value, onChange, className = "", disabled = false }: ColorPickerProps) {
  const [color, setColor] = useState(value || DEFAULT_COLOR)

  // Sync with external value changes
  useEffect(() => {
    if (value && value !== color) {
      setColor(value)
    }
  }, [value])

  // Generate a random color from our predefined vibrant colors
  const generateRandomColor = () => {
    // Get a random color that's different from the current one
    let newColor
    do {
      newColor = VIBRANT_COLORS[Math.floor(Math.random() * VIBRANT_COLORS.length)]
    } while (newColor === color && VIBRANT_COLORS.length > 1)

    setColor(newColor)
    onChange(newColor)
  }

  // Get a friendly name for the color or use the hex code
  const getColorName = (hexColor: string) => {
    return COLOR_NAMES[hexColor] || hexColor
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="flex-1 flex items-center gap-2 border rounded-xl p-2">
        <div
          className="h-6 w-6 rounded-full border shadow-sm"
          style={{ backgroundColor: color }}
          aria-label={`Color: ${getColorName(color)}`}
        />
        <span className="text-sm font-medium">{getColorName(color)}</span>
      </div>

      <Button
        type="button"
        variant="outline"
        size="icon"
        onClick={generateRandomColor}
        disabled={disabled}
        className="h-10 w-10 rounded-xl"
        aria-label="Generate random color"
      >
        <RefreshCw className="h-4 w-4" />
      </Button>
    </div>
  )
}

