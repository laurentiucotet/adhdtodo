"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"

interface TaskTagsProps {
  taskId: string
  className?: string
  onTagClick?: (tagId: string) => void
  getTaskTags: (taskId: string) => Promise<string[]>
  getTagData: (tagId: string) => Promise<{ id: string; name: string; color: string } | null>
}

export function TaskTags({ taskId, className = "", onTagClick, getTaskTags, getTagData }: TaskTagsProps) {
  const [loading, setLoading] = useState(false)
  const [tagIds, setTagIds] = useState<string[]>([])
  const [tagDataMap, setTagDataMap] = useState<Record<string, { name: string; color: string } | null>>({})
  const [dataFetched, setDataFetched] = useState(false)

  // Get tag IDs for this task
  useEffect(() => {
    if (!taskId) return

    let isMounted = true

    const fetchTags = async () => {
      setLoading(true)
      try {
        const fetchedTags = await getTaskTags(taskId)
        if (isMounted) {
          setTagIds(Array.isArray(fetchedTags) ? fetchedTags : [])
          setDataFetched(true)
        }
      } catch (error) {
        console.error(`Error fetching tags for task ${taskId}:`, error)
        if (isMounted) {
          setTagIds([])
          setDataFetched(true)
        }
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    fetchTags()

    return () => {
      isMounted = false
    }
  }, [taskId, getTaskTags])

  // Fetch tag data for all tag IDs
  useEffect(() => {
    if (!tagIds.length) return

    let isMounted = true

    const fetchTagData = async () => {
      const newTagDataMap: Record<string, { name: string; color: string } | null> = {}

      // Create an array of promises for all tag data fetches
      const promises = tagIds.map(async (tagId) => {
        try {
          const data = await getTagData(tagId)
          if (isMounted && data) {
            newTagDataMap[tagId] = data
          }
        } catch (error) {
          console.error(`Error fetching data for tag ${tagId}:`, error)
        }
      })

      // Wait for all promises to resolve
      await Promise.all(promises)

      if (isMounted) {
        setTagDataMap(newTagDataMap)
      }
    }

    fetchTagData()

    return () => {
      isMounted = false
    }
  }, [tagIds, getTagData])

  if (loading && !dataFetched) {
    return (
      <div className={`flex items-center ${className}`}>
        <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!tagIds.length) {
    return null
  }

  return (
    <div className={`flex flex-wrap gap-1 ${className}`}>
      {tagIds.map((tagId) => {
        const tagData = tagDataMap[tagId]
        if (!tagData) return null

        return (
          <div
            key={tagId}
            className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs ${onTagClick ? "cursor-pointer hover:opacity-80" : ""}`}
            style={{
              backgroundColor: `${tagData.color}20`, // 20% opacity
              color: tagData.color,
            }}
            onClick={onTagClick ? () => onTagClick(tagId) : undefined}
            role={onTagClick ? "button" : undefined}
            tabIndex={onTagClick ? 0 : undefined}
          >
            <div className="mr-1 h-1.5 w-1.5 rounded-full" style={{ backgroundColor: tagData.color }} />
            {tagData.name}
          </div>
        )
      })}
    </div>
  )
}

