"use client"

import { useState, useEffect } from "react"
import { useTags } from "@/hooks/use-tags"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface TagFilterChipsProps {
  selectedTagIds: string[]
  onTagSelect: (tagId: string) => void
  onTagDeselect: (tagId: string) => void
  onClearAll: () => void
}

export function TagFilterChips({ selectedTagIds, onTagSelect, onTagDeselect, onClearAll }: TagFilterChipsProps) {
  const { tags, loading } = useTags()
  const [mounted, setMounted] = useState(false)

  // Handle hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  if (loading) {
    return (
      <div className="flex flex-wrap gap-2 py-2">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-8 w-16 animate-pulse rounded-full bg-muted"></div>
        ))}
      </div>
    )
  }

  // Ensure tags is an array
  const safeTags = Array.isArray(tags) ? tags : []

  if (safeTags.length === 0) {
    return null
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Filter by tags</h3>
        {selectedTagIds && selectedTagIds.length > 0 && (
          <Button variant="ghost" size="sm" onClick={onClearAll} className="h-7 px-2 text-xs">
            Clear all
          </Button>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        {safeTags.map((tag) => {
          const isSelected = selectedTagIds && selectedTagIds.includes(tag.id)
          return (
            <button
              key={tag.id}
              onClick={() => (isSelected ? onTagDeselect(tag.id) : onTagSelect(tag.id))}
              className={`
                inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-medium transition-colors
                ${
                  isSelected
                    ? `bg-${tag.color} text-white`
                    : `bg-${tag.color}10 text-${tag.color} hover:bg-${tag.color}20`
                }
              `}
              style={{
                backgroundColor: isSelected ? tag.color : `${tag.color}20`,
                color: isSelected ? "white" : tag.color,
              }}
            >
              <span>{tag.name}</span>
              {isSelected && <X className="h-3 w-3" />}
            </button>
          )
        })}
      </div>
    </div>
  )
}

