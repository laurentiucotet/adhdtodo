"use client"

import { useTags } from "@/hooks/use-tags"
import { X } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface ActiveFiltersBarProps {
  selectedTagIds: string[]
  onTagDeselect: (tagId: string) => void
  onClearAll: () => void
}

export function ActiveFiltersBar({ selectedTagIds, onTagDeselect, onClearAll }: ActiveFiltersBarProps) {
  const { tags } = useTags()

  if (!selectedTagIds || selectedTagIds.length === 0) {
    return null
  }

  // Ensure tags is an array and filter only the selected tags
  const safeTags = Array.isArray(tags) ? tags : []
  const selectedTags = safeTags.filter((tag) => selectedTagIds.includes(tag.id))

  // If no tags match (could happen if tags haven't loaded yet), return null
  if (selectedTags.length === 0) {
    return null
  }

  return (
    <div className="flex items-center gap-2 py-2">
      <span className="text-xs font-medium text-muted-foreground">Active filters:</span>
      <div className="flex flex-wrap gap-1">
        {selectedTags.map((tag) => (
          <Badge
            key={tag.id}
            variant="outline"
            className="flex items-center gap-1 px-2 py-0 h-6"
            style={{ borderColor: tag.color, color: tag.color }}
          >
            <div className="h-2 w-2 rounded-full" style={{ backgroundColor: tag.color }} />
            {tag.name}
            <button onClick={() => onTagDeselect(tag.id)} className="ml-1 rounded-full hover:bg-muted p-0.5">
              <X className="h-3 w-3" />
              <span className="sr-only">Remove {tag.name} filter</span>
            </button>
          </Badge>
        ))}
        {selectedTagIds.length > 1 && (
          <button
            onClick={onClearAll}
            className="text-xs text-muted-foreground hover:text-foreground underline-offset-4 hover:underline"
          >
            Clear all
          </button>
        )}
      </div>
    </div>
  )
}

