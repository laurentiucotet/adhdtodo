"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, RefreshCw } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface AuthErrorFallbackProps {
  error?: string
  onRetry?: () => void
}

export function AuthErrorFallback({ error, onRetry }: AuthErrorFallbackProps) {
  const [isRetrying, setIsRetrying] = useState(false)

  const handleRetry = async () => {
    if (!onRetry) return

    setIsRetrying(true)
    try {
      await onRetry()
    } finally {
      setIsRetrying(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-[400px] p-4">
      <Card className="w-full max-w-md rounded-2xl border-destructive/20">
        <CardHeader className="bg-destructive/5 rounded-t-2xl">
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertCircle className="h-5 w-5" />
            Authentication Error
          </CardTitle>
          <CardDescription>There was a problem connecting to the authentication service</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Alert variant="destructive" className="rounded-xl">
            <AlertDescription>
              {error ||
                "Failed to connect to the authentication service. This might be due to network issues or browser extensions blocking the connection."}
            </AlertDescription>
          </Alert>

          <div className="mt-6 space-y-4">
            <h3 className="text-sm font-medium">Possible solutions:</h3>
            <ul className="list-disc list-inside space-y-2 text-sm text-muted-foreground">
              <li>Check your internet connection</li>
              <li>Disable any browser extensions that might block API requests (especially CORS-related extensions)</li>
              <li>Try using a different browser</li>
              <li>Clear your browser cache and cookies</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          {onRetry && (
            <Button onClick={handleRetry} disabled={isRetrying} className="flex items-center gap-1">
              {isRetrying ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Retrying...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" />
                  Retry Connection
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}

