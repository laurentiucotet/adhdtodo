"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { useTags } from "@/hooks/use-tags"
import { Loader2 } from "lucide-react"
import { useNormalizedStore } from "@/store/normalized-store"

interface TagSelectDialogProps {
  taskId: string
  isOpen: boolean
  onClose: () => void
  onSave: (tagIds: string[]) => void
}

export function TagSelectDialog({ taskId, isOpen, onClose, onSave }: TagSelectDialogProps) {
  const { tags, loading: tagsLoading } = useTags()
  const { taskTags } = useNormalizedStore()
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Initialize selected tags when dialog opens
  useEffect(() => {
    if (isOpen && taskId) {
      const currentTags = taskTags[taskId]
      setSelectedTags(Array.isArray(currentTags) ? currentTags : [])
    }
  }, [isOpen, taskId, taskTags])

  const handleTagToggle = (tagId: string) => {
    setSelectedTags((prev) => {
      if (prev.includes(tagId)) {
        return prev.filter((id) => id !== tagId)
      } else {
        return [...prev, tagId]
      }
    })
  }

  const handleSave = async () => {
    setIsSubmitting(true)
    try {
      onSave(selectedTags)
      onClose()
    } finally {
      setIsSubmitting(false)
    }
  }

  const loading = tagsLoading
  const safeTags = Array.isArray(tags) ? tags : []

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md rounded-xl">
        <DialogHeader>
          <DialogTitle>Manage Tags</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary/70" />
          </div>
        ) : safeTags.length === 0 ? (
          <div className="py-4 text-center">
            <p className="text-muted-foreground">No tags available. Create some tags first.</p>
          </div>
        ) : (
          <div className="max-h-[300px] overflow-y-auto py-2">
            <div className="space-y-2">
              {safeTags.map((tag) => (
                <div key={tag.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`tag-${tag.id}`}
                    checked={selectedTags.includes(tag.id)}
                    onCheckedChange={() => handleTagToggle(tag.id)}
                  />
                  <label
                    htmlFor={`tag-${tag.id}`}
                    className="flex items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: tag.color }} />
                    {tag.name}
                  </label>
                </div>
              ))}
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={loading || isSubmitting}>
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

