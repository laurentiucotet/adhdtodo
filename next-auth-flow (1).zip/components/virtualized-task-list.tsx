"use client"

import type React from "react"

import { useRef, useEffect, useState } from "react"
import { FixedSizeList as List } from "react-window"
import { Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Task } from "@/types"

interface VirtualizedTaskListProps {
  tasks: Task[]
  loading: boolean
  hasMore: boolean
  onLoadMore: () => void
  renderItem: (task: Task, style: React.CSSProperties) => React.ReactNode
  emptyMessage?: string
  loadingMessage?: string
}

export function VirtualizedTaskList({
  tasks,
  loading,
  hasMore,
  onLoadMore,
  renderItem,
  emptyMessage = "No tasks found",
  loadingMessage = "Loading tasks...",
}: VirtualizedTaskListProps) {
  const [listHeight, setListHeight] = useState(500)
  const containerRef = useRef<HTMLDivElement>(null)

  // Ensure tasks is an array
  const safeTasks = Array.isArray(tasks) ? tasks : []

  // Adjust list height based on container size
  useEffect(() => {
    if (!containerRef.current) return

    const updateHeight = () => {
      if (containerRef.current) {
        const containerHeight = containerRef.current.clientHeight
        setListHeight(Math.max(300, containerHeight - 50)) // Minimum height of 300px
      }
    }

    updateHeight()

    const resizeObserver = new ResizeObserver(updateHeight)
    resizeObserver.observe(containerRef.current)

    return () => {
      if (containerRef.current) {
        resizeObserver.unobserve(containerRef.current)
      }
    }
  }, [])

  // Row renderer for react-window
  const Row = ({ index, style }: { index: number; style: React.CSSProperties }) => {
    const task = safeTasks[index]

    // Load more when approaching the end
    if (index === safeTasks.length - 10 && hasMore && !loading) {
      onLoadMore()
    }

    return renderItem(task, style)
  }

  if (loading && safeTasks.length === 0) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary/70" />
          <p className="text-sm text-muted-foreground">{loadingMessage}</p>
        </div>
      </div>
    )
  }

  if (safeTasks.length === 0) {
    return (
      <div className="text-muted-foreground text-center py-8">
        <p>{emptyMessage}</p>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="min-h-[300px] h-full">
      <List
        height={listHeight}
        width="100%"
        itemCount={safeTasks.length}
        itemSize={80} // Adjust based on your task item height
      >
        {Row}
      </List>

      {hasMore && (
        <div className="flex justify-center mt-4">
          <Button variant="outline" size="sm" onClick={onLoadMore} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Loading...
              </>
            ) : (
              "Load More"
            )}
          </Button>
        </div>
      )}
    </div>
  )
}

