"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

export function AutoTaggingInfo() {
  return (
    <Card className="rounded-2xl border-primary/10 overflow-hidden">
      <CardHeader className="bg-primary/5">
        <CardTitle className="text-primary">Automatic Tagging</CardTitle>
        <CardDescription>How keyword-based automatic tagging works</CardDescription>
      </CardHeader>
      <CardContent className="pt-6 space-y-4">
        <Alert className="rounded-xl bg-muted/50">
          <InfoIcon className="h-4 w-4" />
          <AlertDescription>
            Tasks are automatically tagged based on keywords you define for each tag. When you create or edit a task,
            the system checks if any of your defined keywords appear in the task text and applies the corresponding
            tags.
          </AlertDescription>
        </Alert>

        <div className="space-y-2">
          <h3 className="text-sm font-medium">How to use automatic tagging:</h3>
          <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
            <li>Create tags for different categories of tasks</li>
            <li>Add relevant keywords to each tag</li>
            <li>When you create a task containing those keywords, the tag will be automatically applied</li>
            <li>You can still manually add or remove tags from any task</li>
          </ol>
        </div>

        <div className="space-y-2">
          <h3 className="text-sm font-medium">Example:</h3>
          <div className="text-sm text-muted-foreground">
            <p>If you have a "Work" tag with keywords like "meeting", "project", "deadline":</p>
            <p className="mt-1">
              A task titled "Project meeting with team" would automatically get the "Work" tag applied.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

