"use client"

import type React from "react"
import { createContext, useEffect, useState } from "react"
import type { User, Session } from "@supabase/supabase-js"
import { supabaseClient } from "@/utils/supabase/client"
import { useRouter } from "next/navigation"

type AuthContextType = {
  user: User | null
  session: Session | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ error: Error | null }>
  signup: (email: string, password: string, name: string) => Promise<{ error: Error | null }>
  logout: () => Promise<void>
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  isLoading: true,
  login: async () => ({ error: null }),
  signup: async () => ({ error: null }),
  logout: async () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Initialize the auth state from Supabase
  useEffect(() => {
    // Get the initial session
    const initializeAuth = async () => {
      try {
        setIsLoading(true)
        const {
          data: { session },
        } = await supabaseClient.auth.getSession()

        if (session) {
          setSession(session)
          setUser(session.user ?? null)

          // Force a router refresh to ensure server components re-render with the new session
          router.refresh()
        }
      } catch (error) {
        console.error("Error initializing auth:", error)
      } finally {
        setIsLoading(false)
      }
    }

    initializeAuth()

    // Set up the auth state change listener
    const {
      data: { subscription },
    } = supabaseClient.auth.onAuthStateChange(async (_event, session) => {
      setSession(session)
      setUser(session?.user ?? null)

      // Force a router refresh to ensure server components re-render with the new session
      if (session) {
        router.refresh()
      }
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [router])

  const login = async (email: string, password: string) => {
  try {
    setIsLoading(true)
    const { error } = await supabaseClient.auth.signInWithPassword({
      email,
      password,
    })

    if (!error) {
      // Get the redirect param
      const params = new URLSearchParams(window.location.search)
      const redirect = params.get("redirect") || "/dashboard"

      // Redirect to the original page after login
      router.push(redirect)

      // Add a small delay to ensure the session is fully established
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    return { error }
  } catch (error) {
    return { error: error as Error }
  } finally {
    setIsLoading(false)
  }
}


  const signup = async (email: string, password: string, name: string) => {
    try {
      setIsLoading(true)
      const { error } = await supabaseClient.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
        },
      })

      if (!error) {
        // Force a router refresh after successful signup
        router.refresh()
      }

      return { error }
    } catch (error) {
      return { error: error as Error }
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      setIsLoading(true)
      await supabaseClient.auth.signOut()

      // Force a router refresh after logout
      router.refresh()
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, session, isLoading, login, signup, logout }}>{children}</AuthContext.Provider>
  )
}

