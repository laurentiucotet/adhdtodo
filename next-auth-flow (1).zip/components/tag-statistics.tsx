"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useTags } from "@/hooks/use-tags"
import { useTagKeywords } from "@/hooks/use-tag-keywords"
import { Loader2 } from "lucide-react"
import { supabaseClient } from "@/utils/supabase/client"

interface TagStats {
  tagId: string
  tagName: string
  tagColor: string
  keywordCount: number
  taskCount: number
}

export function TagStatistics() {
  const { tags, loading: tagsLoading } = useTags()
  const { keywords, loading: keywordsLoading } = useTagKeywords()
  const [tagStats, setTagStats] = useState<TagStats[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const calculateStats = async () => {
      if (tagsLoading || keywordsLoading || !tags.length) {
        return
      }

      setLoading(true)

      try {
        // Group keywords by tag
        const keywordsByTag = keywords.reduce(
          (acc, kw) => {
            acc[kw.tag_id] = (acc[kw.tag_id] || 0) + 1
            return acc
          },
          {} as Record<string, number>,
        )

        // Get task counts for each tag
        const stats: TagStats[] = []

        for (const tag of tags) {
          // Count tasks with this tag
          const { count, error } = await supabaseClient
            .from("task_tags")
            .select("*", { count: "exact", head: true })
            .eq("tag_id", tag.id)

          if (error) {
            console.error("Error counting tasks for tag:", error)
            continue
          }

          stats.push({
            tagId: tag.id,
            tagName: tag.name,
            tagColor: tag.color,
            keywordCount: keywordsByTag[tag.id] || 0,
            taskCount: count || 0,
          })
        }

        // Sort by task count (most used first)
        stats.sort((a, b) => b.taskCount - a.taskCount)
        setTagStats(stats)
      } catch (err) {
        console.error("Error calculating tag statistics:", err)
      } finally {
        setLoading(false)
      }
    }

    calculateStats()
  }, [tags, keywords, tagsLoading, keywordsLoading])

  return (
    <Card className="rounded-2xl border-primary/10 overflow-hidden">
      <CardHeader className="bg-primary/5">
        <CardTitle className="text-primary">Tag Statistics</CardTitle>
        <CardDescription>Usage statistics for your tags and keywords</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        {loading || tagsLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary/70" />
          </div>
        ) : tagStats.length === 0 ? (
          <p className="text-muted-foreground text-center py-4">
            No tag statistics available. Create some tags and add tasks to see statistics.
          </p>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-muted/30 p-4 rounded-xl">
                <h3 className="text-sm font-medium mb-2">Most Used Tags</h3>
                <ul className="space-y-2">
                  {tagStats.slice(0, 5).map((stat) => (
                    <li key={stat.tagId} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: stat.tagColor }} />
                        <span className="text-sm">{stat.tagName}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{stat.taskCount} tasks</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-muted/30 p-4 rounded-xl">
                <h3 className="text-sm font-medium mb-2">Keyword Statistics</h3>
                <ul className="space-y-2">
                  {tagStats.slice(0, 5).map((stat) => (
                    <li key={stat.tagId} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: stat.tagColor }} />
                        <span className="text-sm">{stat.tagName}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{stat.keywordCount} keywords</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="bg-muted/30 p-4 rounded-xl">
              <h3 className="text-sm font-medium mb-2">All Tags</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {tagStats.map((stat) => (
                  <div key={stat.tagId} className="bg-background p-2 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: stat.tagColor }} />
                      <span className="text-sm font-medium">{stat.tagName}</span>
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{stat.taskCount} tasks</span>
                      <span>{stat.keywordCount} keywords</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

