"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ColorPicker } from "@/components/color-picker"
import { useTags, type Tag } from "@/hooks/use-tags"
import { Loader2, Plus, Pencil, Trash2, X, Check, ChevronDown, ChevronUp, TagIcon } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { TagKeywordsManager } from "@/components/tag-keywords-manager"

export function TagManagement() {
  const { tags, loading, error, addTag, updateTag, deleteTag } = useTags()
  const [newTagName, setNewTagName] = useState("")
  const [newTagColor, setNewTagColor] = useState("#3b82f6")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [editingTag, setEditingTag] = useState<Tag | null>(null)
  const [editName, setEditName] = useState("")
  const [editColor, setEditColor] = useState("")
  const [expandedTagId, setExpandedTagId] = useState<string | null>(null)

  // Add a new tag
  const handleAddTag = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newTagName.trim() === "") return

    setIsSubmitting(true)
    try {
      await addTag(newTagName, newTagColor)
      setNewTagName("") // Clear the input field
      setNewTagColor("#3b82f6") // Reset to default color
    } finally {
      setIsSubmitting(false)
    }
  }

  // Start editing a tag
  const startEditing = (tag: Tag) => {
    setEditingTag(tag)
    setEditName(tag.name)
    setEditColor(tag.color)
  }

  // Cancel editing
  const cancelEditing = () => {
    setEditingTag(null)
    setEditName("")
    setEditColor("")
  }

  // Save edited tag
  const saveEditedTag = async (id: string) => {
    if (editName.trim() === "") return

    setIsSubmitting(true)
    try {
      await updateTag(id, { name: editName, color: editColor })
      cancelEditing()
    } finally {
      setIsSubmitting(false)
    }
  }

  // Delete a tag
  const handleDeleteTag = async (id: string) => {
    if (confirm("Are you sure you want to delete this tag? It will be removed from all tasks.")) {
      await deleteTag(id)
    }
  }

  // Toggle expanded tag for keyword management
  const toggleExpandTag = (tagId: string) => {
    setExpandedTagId(expandedTagId === tagId ? null : tagId)
  }

  return (
    <Card className="rounded-2xl border-primary/10 overflow-hidden">
      <CardHeader className="bg-primary/5">
        <CardTitle className="text-primary">Tag Management</CardTitle>
        <CardDescription>Create and manage tags and their keywords for automatic task tagging</CardDescription>
      </CardHeader>

      <CardContent className="pt-6 space-y-6">
        {/* New tag form */}
        <form onSubmit={handleAddTag} className="space-y-4">
          <h3 className="text-lg font-medium">Create New Tag</h3>
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Tag name"
              value={newTagName}
              onChange={(e) => setNewTagName(e.target.value)}
              className="rounded-xl flex-1"
              disabled={isSubmitting}
            />
            <div className="w-full sm:w-40" onClick={(e) => e.stopPropagation()}>
              <ColorPicker value={newTagColor} onChange={setNewTagColor} className="rounded-xl" />
            </div>
            <Button
              type="submit"
              className="flex items-center gap-1"
              disabled={isSubmitting || newTagName.trim() === ""}
            >
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              <span>Add Tag</span>
            </Button>
          </div>
        </form>

        {/* Error message */}
        {error && (
          <Alert variant="destructive" className="rounded-xl">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Tags list */}
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Your Tags</h3>
          <div className="border rounded-xl overflow-hidden">
            {loading ? (
              <div className="flex justify-center items-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary/70" />
              </div>
            ) : tags.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No tags available. Create some tags to get started.
              </p>
            ) : (
              <ul className="divide-y">
                {tags.map((tag) => (
                  <li key={tag.id} className="hover:bg-muted/50 transition-colors">
                    {editingTag?.id === tag.id ? (
                      <div className="p-3 flex flex-col sm:flex-row gap-2">
                        <Input
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="rounded-xl flex-1"
                          disabled={isSubmitting}
                        />
                        <div className="w-full sm:w-40">
                          <ColorPicker value={editColor} onChange={setEditColor} className="rounded-xl" />
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={cancelEditing} disabled={isSubmitting}>
                            <X className="h-4 w-4" />
                            <span className="sr-only">Cancel</span>
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => saveEditedTag(tag.id)}
                            disabled={isSubmitting || editName.trim() === ""}
                          >
                            {isSubmitting ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Check className="h-4 w-4" />
                            )}
                            <span className="sr-only">Save</span>
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="p-3 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="h-4 w-4 rounded-full" style={{ backgroundColor: tag.color }} />
                            <span>{tag.name}</span>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => toggleExpandTag(tag.id)}
                              className="flex items-center gap-1"
                            >
                              <TagIcon className="h-4 w-4" />
                              <span className="text-xs">Keywords</span>
                              {expandedTagId === tag.id ? (
                                <ChevronUp className="h-3 w-3" />
                              ) : (
                                <ChevronDown className="h-3 w-3" />
                              )}
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => startEditing(tag)}>
                              <Pencil className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => handleDeleteTag(tag.id)}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </div>
                        {expandedTagId === tag.id && (
                          <div className="px-3 pb-3 pt-0 bg-muted/20 border-t">
                            <TagKeywordsManager tagId={tag.id} tagName={tag.name} tagColor={tag.color} />
                          </div>
                        )}
                      </>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

