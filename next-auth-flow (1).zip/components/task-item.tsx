"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, Tag, Check, X, Edit2, Loader2 } from "lucide-react"
import { TaskTags } from "@/components/task-tags"
import type { Task } from "@/types"

interface TaskItemProps {
  task: Task
  style?: React.CSSProperties
  onToggleCompletion: (id: string) => Promise<boolean>
  onUpdateTask: (id: string, text: string) => Promise<boolean>
  onDeleteTask: (id: string) => Promise<boolean>
  onOpenTagDialog: (id: string) => void
  onTagClick?: (tagId: string) => void
  getTaskTags: (taskId: string) => Promise<string[]>
  getTagData: (tagId: string) => Promise<{ id: string; name: string; color: string } | null>
}

export function TaskItem({
  task,
  style,
  onToggleCompletion,
  onUpdateTask,
  onDeleteTask,
  onOpenTagDialog,
  onTagClick,
  getTaskTags,
  getTagData,
}: TaskItemProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editText, setEditText] = useState(task.text)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)
  const [isTogglingCompletion, setIsTogglingCompletion] = useState(false)
  const [tags, setTags] = useState<string[]>([])
  const [tagsLoaded, setTagsLoaded] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  // Load tags when component mounts
  useEffect(() => {
    let isMounted = true

    const loadTags = async () => {
      try {
        const taskTags = await getTaskTags(task.id)
        if (isMounted) {
          setTags(taskTags)
          setTagsLoaded(true)
        }
      } catch (err) {
        console.error(`Error loading tags for task ${task.id}:`, err)
        if (isMounted) {
          setTagsLoaded(true) // Mark as loaded even on error
        }
      }
    }

    loadTags()

    return () => {
      isMounted = false
    }
  }, [task.id, getTaskTags])

  // Focus the input when editing starts
  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isEditing])

  // Handle task completion toggle
  const handleToggleCompletion = useCallback(
    async (e: React.MouseEvent) => {
      e.stopPropagation() // Prevent event bubbling

      if (isTogglingCompletion) return

      setIsTogglingCompletion(true)
      try {
        await onToggleCompletion(task.id)
      } catch (err) {
        console.error("Error toggling task completion:", err)
      } finally {
        setIsTogglingCompletion(false)
      }
    },
    [task.id, onToggleCompletion, isTogglingCompletion],
  )

  // Start editing the task
  const handleStartEdit = () => {
    setIsEditing(true)
    setEditText(task.text)
  }

  // Cancel editing
  const handleCancelEdit = () => {
    setIsEditing(false)
    setEditText(task.text)
  }

  // Save the edited task
  const handleSaveEdit = async () => {
    if (editText.trim() === "" || editText === task.text) {
      setIsEditing(false)
      return
    }

    setIsUpdating(true)
    try {
      await onUpdateTask(task.id, editText)
      setIsEditing(false)
    } catch (err) {
      console.error("Error updating task:", err)
    } finally {
      setIsUpdating(false)
    }
  }

  // Delete the task
  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await onDeleteTask(task.id)
    } catch (err) {
      console.error("Error deleting task:", err)
      setIsDeleting(false)
    }
  }

  // Open tag dialog
  const handleOpenTagDialog = (e: React.MouseEvent) => {
    e.stopPropagation()
    onOpenTagDialog(task.id)
  }

  // Check if this task is a temporary task (optimistic update)
  const isPending = task.id.startsWith("temp-")

  return (
    <div
      className={`group flex items-start gap-3 p-3 border-b transition-colors hover:bg-muted/20 ${
        task.completed ? "bg-muted/10" : ""
      }`}
      style={style}
      onClick={(e) => {
        // Prevent clicks on the container from triggering checkbox
        e.stopPropagation()
      }}
    >
      <div className="flex-shrink-0 pt-0.5">
        <Checkbox
          id={`task-${task.id}`}
          checked={task.completed}
          onCheckedChange={() => handleToggleCompletion(new MouseEvent("click") as any)}
          disabled={isTogglingCompletion || isPending}
          className="cursor-pointer"
        />
      </div>

      <div className="flex-grow min-w-0">
        {isEditing ? (
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              className="flex-grow"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSaveEdit()
                } else if (e.key === "Escape") {
                  handleCancelEdit()
                }
              }}
            />
            <div className="flex gap-1">
              <Button
                size="icon"
                variant="ghost"
                onClick={handleSaveEdit}
                disabled={isUpdating || editText.trim() === ""}
                className="h-9 w-9"
              >
                {isUpdating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              </Button>
              <Button size="icon" variant="ghost" onClick={handleCancelEdit} className="h-9 w-9">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div>
            <label
              htmlFor={`task-${task.id}`}
              className={`text-sm select-none ${task.completed ? "line-through text-muted-foreground" : ""}`}
              onClick={(e) => {
                // Prevent label clicks from bubbling to container
                e.stopPropagation()
              }}
            >
              {task.text}
              {isPending && <span className="ml-2 text-xs text-muted-foreground italic">Saving...</span>}
            </label>

            {tagsLoaded && (
              <TaskTags
                taskId={task.id}
                getTaskTags={() => Promise.resolve(tags)} // Use cached tags
                getTagData={getTagData}
                onTagClick={onTagClick}
                className="mt-1.5"
              />
            )}
          </div>
        )}
      </div>

      {!isEditing && (
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            size="icon"
            variant="ghost"
            onClick={handleStartEdit}
            className="h-8 w-8"
            title="Edit task"
            disabled={isPending}
          >
            <Edit2 className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            onClick={handleOpenTagDialog}
            className="h-8 w-8"
            title="Manage tags"
            disabled={isPending}
          >
            <Tag className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            onClick={handleDelete}
            disabled={isDeleting || isPending}
            className="h-8 w-8 text-destructive hover:text-destructive"
            title="Delete task"
          >
            {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
          </Button>
        </div>
      )}
    </div>
  )
}

