/**
 * Theme configuration for the application
 * This file centralizes theme settings that can be imported and used
 * throughout the application for consistent styling
 */

export const themeConfig = {
  // Main colors
  colors: {
    primary: {
      light: "hsl(215, 100%, 50%)",
      dark: "hsl(215, 100%, 60%)",
    },
    secondary: {
      light: "hsl(214, 100%, 96%)",
      dark: "hsl(215, 50%, 20%)",
    },
    accent: {
      light: "hsl(214, 100%, 94%)",
      dark: "hsl(215, 50%, 25%)",
    },
    destructive: {
      light: "hsl(0, 84.2%, 60.2%)",
      dark: "hsl(0, 62.8%, 30.6%)",
    },
    success: {
      light: "hsl(142.1, 76.2%, 36.3%)",
      dark: "hsl(142.1, 70.6%, 45.3%)",
    },
    warning: {
      light: "hsl(38, 92%, 50%)",
      dark: "hsl(48, 96%, 89%)",
    },
    info: {
      light: "hsl(215, 100%, 50%)",
      dark: "hsl(215, 100%, 60%)",
    },
  },

  // Typography
  typography: {
    fontFamily: {
      sans: "'M PLUS Rounded 1c', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
      mono: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
    },
    fontSize: {
      xs: "0.75rem",
      sm: "0.875rem",
      base: "1rem",
      lg: "1.125rem",
      xl: "1.25rem",
      "2xl": "1.5rem",
      "3xl": "1.875rem",
      "4xl": "2.25rem",
      "5xl": "3rem",
    },
    fontWeight: {
      normal: "400",
      medium: "500",
      semibold: "600",
      bold: "700",
    },
    lineHeight: {
      none: "1",
      tight: "1.25",
      snug: "1.375",
      normal: "1.5",
      relaxed: "1.625",
      loose: "2",
    },
  },

  // Spacing
  spacing: {
    0: "0",
    1: "0.25rem",
    2: "0.5rem",
    3: "0.75rem",
    4: "1rem",
    5: "1.25rem",
    6: "1.5rem",
    8: "2rem",
    10: "2.5rem",
    12: "3rem",
    16: "4rem",
    20: "5rem",
    24: "6rem",
    32: "8rem",
    40: "10rem",
    48: "12rem",
    56: "14rem",
    64: "16rem",
  },

  // Border radius
  borderRadius: {
    none: "0",
    sm: "0.5rem",
    DEFAULT: "1rem",
    md: "1.5rem",
    lg: "2rem",
    xl: "2.5rem",
    "2xl": "3rem",
    "3xl": "3.5rem",
    full: "9999px",
  },

  // Transitions
  transitions: {
    DEFAULT: "150ms cubic-bezier(0.4, 0, 0.2, 1)",
    fast: "100ms cubic-bezier(0.4, 0, 0.2, 1)",
    slow: "300ms cubic-bezier(0.4, 0, 0.2, 1)",
  },

  // Shadows
  shadows: {
    sm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
    DEFAULT: "0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)",
    md: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
    lg: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
    xl: "0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)",
  },

  // Layout
  layout: {
    headerHeight: "4rem",
    footerHeight: "3.5rem",
    sidebarWidth: "16rem",
    contentMaxWidth: "1200px",
    contentPadding: "1.5rem",
  },
}

// Helper function to get CSS variable value
export function getCssVar(variable: string): string {
  if (typeof window !== "undefined") {
    const computedStyle = getComputedStyle(document.documentElement)
    return computedStyle.getPropertyValue(`--${variable}`).trim()
  }
  return ""
}

// Helper function to set CSS variable
export function setCssVar(variable: string, value: string): void {
  if (typeof window !== "undefined") {
    document.documentElement.style.setProperty(`--${variable}`, value)
  }
}

