import { setCssVar } from "./theme-config"

/**
 * Updates the primary color of the application
 * @param hue - The hue value (0-360)
 * @param saturation - The saturation value (0-100)
 * @param lightness - The lightness value (0-100)
 */
export function updatePrimaryColor(hue: number, saturation: number, lightness: number): void {
  // Update light theme primary
  setCssVar("primary", `${hue} ${saturation}% ${lightness}%`)
  setCssVar("primary-foreground", "210 40% 98%")

  // Update dark theme primary
  // For dark theme, we typically invert the colors
  setCssVar("primary", `${hue} ${saturation}% ${98 - lightness}%`)
  setCssVar("primary-foreground", `${hue} ${saturation}% ${lightness}%`)
}

/**
 * Updates the border radius throughout the application
 * @param value - The border radius value (e.g., "0.5rem")
 */
export function updateBorderRadius(value: string): void {
  setCssVar("radius", value)
}

/**
 * Applies a preset theme to the application
 * @param preset - The theme preset name
 */
export function applyThemePreset(preset: "default" | "rounded" | "sharp" | "purple" | "blue" | "green"): void {
  switch (preset) {
    case "default":
      // Reset to default theme
      updateBorderRadius("0.5rem")
      updatePrimaryColor(222.2, 47.4, 11.2)
      break
    case "rounded":
      // More rounded corners
      updateBorderRadius("1rem")
      updatePrimaryColor(222.2, 47.4, 11.2)
      break
    case "sharp":
      // Sharp corners
      updateBorderRadius("0.125rem")
      updatePrimaryColor(222.2, 47.4, 11.2)
      break
    case "purple":
      // Purple theme
      updateBorderRadius("0.5rem")
      updatePrimaryColor(270, 50, 40)
      break
    case "blue":
      // Blue theme
      updateBorderRadius("0.5rem")
      updatePrimaryColor(210, 100, 50)
      break
    case "green":
      // Green theme
      updateBorderRadius("0.5rem")
      updatePrimaryColor(142, 72, 29)
      break
    default:
      // Default theme
      updateBorderRadius("0.5rem")
      updatePrimaryColor(222.2, 47.4, 11.2)
  }
}

/**
 * Gets a color with specific opacity
 * @param colorName - The name of the color (e.g., "primary")
 * @param opacity - The opacity value (0-100)
 * @returns The color with opacity as a string
 */
export function getColorWithOpacity(colorName: string, opacity: number): string {
  return `hsl(var(--${colorName}) / ${opacity}%)`
}

