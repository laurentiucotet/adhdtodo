import { createBrowserClient } from "@supabase/ssr"

// Create a singleton Supabase client for the browser
let supabaseInstance = null

// Function to create/get the Supabase client
export const createClient = () => {
  if (supabaseInstance) return supabaseInstance

  supabaseInstance = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  )

  return supabaseInstance
}

// Export the client instance directly for backward compatibility
export const supabaseClient = createClient()

