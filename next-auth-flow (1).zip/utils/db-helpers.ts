import { supabaseClient } from "@/utils/supabase/client"

/**
 * Utility functions for common database operations
 */

/**
 * Checks if a record exists in a table
 * @param table The table name
 * @param column The column to check
 * @param value The value to check for
 * @returns Boolean indicating if the record exists
 */
export async function recordExists(table: string, column: string, value: any): Promise<boolean> {
  const { count, error } = await supabaseClient
    .from(table)
    .select("*", { count: "exact", head: true })
    .eq(column, value)

  if (error) {
    console.error(`Error checking if record exists in ${table}:`, error)
    return false
  }

  return count !== null && count > 0
}

/**
 * Gets all records from a table
 * @param table The table name
 * @param orderBy Optional column to order by
 * @param ascending Whether to order ascending or descending
 * @returns Array of records
 */
export async function getAllRecords<T>(table: string, orderBy?: string, ascending = true): Promise<T[]> {
  let query = supabaseClient.from(table).select("*")

  if (orderBy) {
    query = query.order(orderBy, { ascending })
  }

  const { data, error } = await query

  if (error) {
    console.error(`Error fetching records from ${table}:`, error)
    return []
  }

  return data as T[]
}

/**
 * Gets records from a table with a filter
 * @param table The table name
 * @param column The column to filter on
 * @param value The value to filter for
 * @param orderBy Optional column to order by
 * @param ascending Whether to order ascending or descending
 * @returns Array of filtered records
 */
export async function getFilteredRecords<T>(
  table: string,
  column: string,
  value: any,
  orderBy?: string,
  ascending = true,
): Promise<T[]> {
  let query = supabaseClient.from(table).select("*").eq(column, value)

  if (orderBy) {
    query = query.order(orderBy, { ascending })
  }

  const { data, error } = await query

  if (error) {
    console.error(`Error fetching filtered records from ${table}:`, error)
    return []
  }

  return data as T[]
}

/**
 * Inserts a record into a table
 * @param table The table name
 * @param record The record to insert
 * @returns The inserted record or null if error
 */
export async function insertRecord<T>(table: string, record: any): Promise<T | null> {
  const { data, error } = await supabaseClient.from(table).insert(record).select().single()

  if (error) {
    console.error(`Error inserting record into ${table}:`, error)
    return null
  }

  return data as T
}

/**
 * Updates a record in a table
 * @param table The table name
 * @param id The ID of the record to update
 * @param updates The updates to apply
 * @returns Boolean indicating success
 */
export async function updateRecord(table: string, id: string, updates: any): Promise<boolean> {
  const { error } = await supabaseClient.from(table).update(updates).eq("id", id)

  if (error) {
    console.error(`Error updating record in ${table}:`, error)
    return false
  }

  return true
}

/**
 * Deletes a record from a table
 * @param table The table name
 * @param id The ID of the record to delete
 * @returns Boolean indicating success
 */
export async function deleteRecord(table: string, id: string): Promise<boolean> {
  const { error } = await supabaseClient.from(table).delete().eq("id", id)

  if (error) {
    console.error(`Error deleting record from ${table}:`, error)
    return false
  }

  return true
}

