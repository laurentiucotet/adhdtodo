import { supabaseClient } from "@/utils/supabase/client"
import type { Task } from "@/types"
import { insertRecord, updateRecord, deleteRecord, getFilteredRecords } from "@/utils/db-helpers"
import { TagKeywordsService } from "./tag-keywords-service"

/**
 * Service for managing tasks
 */
export const TaskService = {
  /**
   * Gets all tasks
   * @param userId The user ID
   * @returns Array of tasks
   */
  async getAllTasks(userId: string): Promise<Task[]> {
    return getFilteredRecords<Task>("tasks", "user_id", userId, "created_at", false)
  },

  /**
   * Gets a task by ID
   * @param taskId The task ID
   * @returns The task or null if not found
   */
  async getTaskById(taskId: string): Promise<Task | null> {
    const { data, error } = await supabaseClient.from("tasks").select("*").eq("id", taskId).single()

    if (error) {
      console.error("Error fetching task:", error)
      return null
    }

    return data as Task
  },

  /**
   * Creates a new task
   * @param userId The user ID
   * @param text The task text
   * @returns The created task or null if error
   */
  async createTask(userId: string, text: string): Promise<Task | null> {
    if (!userId || !text.trim()) return null

    const task = await insertRecord<Task>("tasks", {
      user_id: userId,
      text: text.trim(),
      completed: false,
    })

    if (task) {
      // Auto-assign tags based on keywords
      await this.autoAssignTags(task.id, text)
    }

    return task
  },

  /**
   * Updates a task
   * @param taskId The task ID
   * @param updates The updates to apply
   * @returns Boolean indicating success
   */
  async updateTask(taskId: string, updates: Partial<Omit<Task, "id" | "created_at" | "updated_at">>): Promise<boolean> {
    const success = await updateRecord("tasks", taskId, updates)

    // If the task text was updated, re-evaluate tags
    if (success && updates.text) {
      await this.autoAssignTags(taskId, updates.text)
    }

    return success
  },

  /**
   * Deletes a task
   * @param taskId The task ID
   * @returns Boolean indicating success
   */
  async deleteTask(taskId: string): Promise<boolean> {
    return deleteRecord("tasks", taskId)
  },

  /**
   * Toggles the completion status of a task
   * @param taskId The task ID
   * @param currentStatus The current completion status
   * @returns Boolean indicating success
   */
  async toggleTaskCompletion(taskId: string, currentStatus: boolean): Promise<boolean> {
    return updateRecord("tasks", taskId, { completed: !currentStatus })
  },

  /**
   * Auto-assigns tags to a task based on keywords
   * @param taskId The task ID
   * @param taskText The task text
   * @returns Boolean indicating success
   */
  async autoAssignTags(taskId: string, taskText: string): Promise<boolean> {
    try {
      // Find matching tags based on keywords
      const matchingTagIds = await TagKeywordsService.findMatchingTags(taskText)

      if (matchingTagIds.length === 0) {
        return true // No matching tags, nothing to do
      }

      // Get existing tags for this task
      const { data: existingTaskTags } = await supabaseClient.from("task_tags").select("tag_id").eq("task_id", taskId)

      const existingTagIds = existingTaskTags?.map((tt) => tt.tag_id) || []

      // Combine existing tags with new matching tags (avoid duplicates)
      const allTagIds = Array.from(new Set([...existingTagIds, ...matchingTagIds]))

      // Assign all tags to the task
      return TagKeywordsService.assignTagsToTask(taskId, allTagIds)
    } catch (err) {
      console.error("Error auto-assigning tags:", err)
      return false
    }
  },

  /**
   * Gets all tags for a task
   * @param taskId The task ID
   * @returns Array of tag IDs
   */
  async getTaskTags(taskId: string): Promise<string[]> {
    const { data, error } = await supabaseClient.from("task_tags").select("tag_id").eq("task_id", taskId)

    if (error) {
      console.error("Error fetching task tags:", error)
      return []
    }

    return data.map((item) => item.tag_id)
  },

  /**
   * Updates tags for a task
   * @param taskId The task ID
   * @param tagIds Array of tag IDs to assign
   * @returns Boolean indicating success
   */
  async updateTaskTags(taskId: string, tagIds: string[]): Promise<boolean> {
    if (!taskId) return false

    try {
      // First, remove all existing tags for this task
      const { error: deleteError } = await supabaseClient.from("task_tags").delete().eq("task_id", taskId)

      if (deleteError) {
        throw deleteError
      }

      // Then, add the new tags
      if (tagIds.length > 0) {
        const newTaskTags = tagIds.map((tagId) => ({
          task_id: taskId,
          tag_id: tagId,
        }))

        const { error: insertError } = await supabaseClient.from("task_tags").insert(newTaskTags)

        if (insertError) {
          throw insertError
        }
      }

      return true
    } catch (err) {
      console.error("Error updating task tags:", err)
      return false
    }
  },
}

