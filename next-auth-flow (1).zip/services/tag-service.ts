import { supabaseClient } from "@/utils/supabase/client"
import type { Tag } from "@/hooks/use-tags"
import { getFilteredRecords, insertRecord, updateRecord, deleteRecord } from "@/utils/db-helpers"

/**
 * Service for managing tags
 */
export const TagService = {
  /**
   * Gets all tags for a user
   * @param userId The user ID
   * @returns Array of tags
   */
  async getAllTags(userId: string): Promise<Tag[]> {
    return getFilteredRecords<Tag>("tags", "user_id", userId, "name")
  },

  /**
   * Gets a tag by ID
   * @param tagId The tag ID
   * @returns The tag or null if not found
   */
  async getTagById(tagId: string): Promise<Tag | null> {
    const { data, error } = await supabaseClient.from("tags").select("*").eq("id", tagId).single()

    if (error) {
      console.error("Error fetching tag:", error)
      return null
    }

    return data as Tag
  },

  /**
   * Creates a new tag
   * @param userId The user ID
   * @param name The tag name
   * @param color The tag color
   * @returns The created tag or null if error
   */
  async createTag(userId: string, name: string, color: string): Promise<Tag | null> {
    return insertRecord<Tag>("tags", {
      user_id: userId,
      name: name.trim(),
      color: color || "#3b82f6", // Default to blue if no color provided
    })
  },

  /**
   * Updates a tag
   * @param tagId The tag ID
   * @param updates The updates to apply
   * @returns Boolean indicating success
   */
  async updateTag(tagId: string, updates: { name?: string; color?: string }): Promise<boolean> {
    return updateRecord("tags", tagId, updates)
  },

  /**
   * Deletes a tag
   * @param tagId The tag ID
   * @returns Boolean indicating success
   */
  async deleteTag(tagId: string): Promise<boolean> {
    return deleteRecord("tags", tagId)
  },

  /**
   * Gets all tags for a task
   * @param taskId The task ID
   * @returns Array of tags
   */
  async getTagsForTask(taskId: string): Promise<Tag[]> {
    const { data, error } = await supabaseClient.from("task_tags").select("tag_id").eq("task_id", taskId)

    if (error || !data.length) {
      return []
    }

    const tagIds = data.map((item) => item.tag_id)

    const { data: tags, error: tagsError } = await supabaseClient
      .from("tags")
      .select("*")
      .in("id", tagIds)
      .order("name")

    if (tagsError) {
      console.error("Error fetching tags for task:", tagsError)
      return []
    }

    return tags as Tag[]
  },
}

