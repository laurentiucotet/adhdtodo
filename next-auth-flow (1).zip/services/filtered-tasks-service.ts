import { supabaseClient } from "@/utils/supabase/client"
import type { Task } from "@/types"

interface TaskFilterOptions {
  userId: string
  completed?: boolean
  tagIds?: string[]
  limit?: number
  cursor?: string
  sortBy?: "created_at" | "updated_at" | "text"
  sortDirection?: "asc" | "desc"
  fields?: string[] // Add support for field selection
}

/**
 * Service for fetching filtered tasks from the server
 */
export const FilteredTasksService = {
  /**
   * Gets tasks with server-side filtering and cursor-based pagination
   * @param options Filter options
   * @returns Filtered tasks, next cursor, and total count
   */
  async getFilteredTasks(options: TaskFilterOptions): Promise<{
    tasks: Task[]
    nextCursor: string | null
    count: number
  }> {
    try {
      const {
        userId,
        completed,
        tagIds,
        limit = 20,
        cursor,
        sortBy = "created_at",
        sortDirection = "desc",
        fields = ["id", "text", "completed", "created_at", "updated_at"], // Default fields
      } = options

      // Create a comma-separated list of fields for the select statement
      const selectFields = fields.join(",")

      // Start building the query with field selection
      let query = supabaseClient.from("tasks").select(selectFields, { count: "exact" }).eq("user_id", userId)

      // Apply completed filter if specified
      if (completed !== undefined) {
        query = query.eq("completed", completed)
      }

      // Apply tag filtering if specified
      if (tagIds && tagIds.length > 0) {
        try {
          // First get task IDs that have the specified tags
          const { data: taskTagsData, error: tagError } = await supabaseClient
            .from("task_tags")
            .select("task_id")
            .in("tag_id", tagIds)

          if (tagError) {
            console.error("Error fetching task tags:", tagError)
            throw tagError
          }

          if (taskTagsData && taskTagsData.length > 0) {
            // Extract unique task IDs
            const taskIds = [...new Set(taskTagsData.map((item) => item.task_id))]

            // Apply task ID filter
            query = query.in("id", taskIds)
          } else {
            // No tasks match the tag filter, return empty result
            return { tasks: [], nextCursor: null, count: 0 }
          }
        } catch (tagErr) {
          console.error("Error in tag filtering:", tagErr)
          // Continue without tag filtering if there's an error
        }
      }

      // Apply cursor-based pagination
      if (cursor) {
        if (sortDirection === "desc") {
          query = query.lt(sortBy, cursor)
        } else {
          query = query.gt(sortBy, cursor)
        }
      }

      // Apply ordering and limit
      const { data, count, error } = await query.order(sortBy, { ascending: sortDirection === "asc" }).limit(limit)

      if (error) {
        console.error("Error fetching filtered tasks:", error)
        throw error
      }

      // Determine the next cursor
      let nextCursor: string | null = null
      if (data && data.length === limit) {
        nextCursor = data[data.length - 1][sortBy]
      }

      // Ensure data is an array
      const safeData = Array.isArray(data) ? data : []

      return {
        tasks: safeData as Task[],
        nextCursor,
        count: count || 0,
      }
    } catch (err) {
      console.error("Error in getFilteredTasks:", err)
      return { tasks: [], nextCursor: null, count: 0 }
    }
  },

  /**
   * Lazy loads tags for a batch of tasks with minimal data
   * @param taskIds Array of task IDs
   * @returns Map of task ID to tag IDs
   */
  async lazyLoadTaskTags(taskIds: string[]): Promise<Record<string, string[]>> {
    if (!taskIds || !taskIds.length) return {}

    try {
      // Only select the necessary fields
      const { data, error } = await supabaseClient.from("task_tags").select("task_id, tag_id").in("task_id", taskIds)

      if (error) {
        console.error("Error lazy loading task tags:", error)
        return {}
      }

      // Ensure data is an array
      const safeData = Array.isArray(data) ? data : []

      // Group tags by task ID
      const taskTagsMap: Record<string, string[]> = {}

      safeData.forEach((item) => {
        if (!taskTagsMap[item.task_id]) {
          taskTagsMap[item.task_id] = []
        }
        taskTagsMap[item.task_id].push(item.tag_id)
      })

      return taskTagsMap
    } catch (err) {
      console.error("Error in lazyLoadTaskTags:", err)
      return {}
    }
  },

  /**
   * Gets minimal tag data for display
   * @param tagIds Array of tag IDs
   * @returns Array of minimal tag objects with id, name, and color
   */
  async getMinimalTagData(tagIds: string[]): Promise<Array<{ id: string; name: string; color: string }>> {
    if (!tagIds || !tagIds.length) return []

    try {
      // Only select the necessary fields
      const { data, error } = await supabaseClient.from("tags").select("id, name, color").in("id", tagIds)

      if (error) {
        console.error("Error fetching minimal tag data:", error)
        return []
      }

      // Ensure data is an array
      return Array.isArray(data) ? data : []
    } catch (err) {
      console.error("Error in getMinimalTagData:", err)
      return []
    }
  },
}

