import { supabaseClient } from "@/utils/supabase/client"
import type { TagKeyword } from "@/hooks/use-tag-keywords"
import { getAllRecords, getFilteredRecords, insertRecord, updateRecord, deleteRecord } from "@/utils/db-helpers"

/**
 * Service for managing tag keywords
 */
export const TagKeywordsService = {
  /**
   * Gets all keywords for a specific tag
   * @param tagId The tag ID
   * @returns Array of keywords
   */
  async getKeywordsByTagId(tagId: string): Promise<TagKeyword[]> {
    return getFilteredRecords<TagKeyword>("tag_keywords", "tag_id", tagId, "keyword")
  },

  /**
   * Gets all keywords
   * @returns Array of all keywords
   */
  async getAllKeywords(): Promise<TagKeyword[]> {
    return getAllRecords<TagKeyword>("tag_keywords", "keyword")
  },

  /**
   * Adds a new keyword to a tag
   * @param tagId The tag ID
   * @param keyword The keyword to add
   * @returns The created keyword or null if error
   */
  async addKeyword(tagId: string, keyword: string): Promise<TagKeyword | null> {
    const normalizedKeyword = keyword.trim().toLowerCase()

    // Check if keyword already exists for this tag
    const { data: existingKeywords } = await supabaseClient
      .from("tag_keywords")
      .select("*")
      .eq("tag_id", tagId)
      .eq("keyword", normalizedKeyword)

    if (existingKeywords && existingKeywords.length > 0) {
      console.log("Keyword already exists for this tag")
      return existingKeywords[0] as TagKeyword
    }

    return insertRecord<TagKeyword>("tag_keywords", {
      tag_id: tagId,
      keyword: normalizedKeyword,
    })
  },

  /**
   * Updates a keyword
   * @param keywordId The keyword ID
   * @param newKeyword The new keyword value
   * @returns Boolean indicating success
   */
  async updateKeyword(keywordId: string, newKeyword: string): Promise<boolean> {
    const normalizedKeyword = newKeyword.trim().toLowerCase()
    return updateRecord("tag_keywords", keywordId, { keyword: normalizedKeyword })
  },

  /**
   * Deletes a keyword
   * @param keywordId The keyword ID
   * @returns Boolean indicating success
   */
  async deleteKeyword(keywordId: string): Promise<boolean> {
    return deleteRecord("tag_keywords", keywordId)
  },

  /**
   * Finds tags that match keywords in the given text
   * @param text The text to check for keywords
   * @returns Array of matching tag IDs
   */
  async findMatchingTags(text: string): Promise<string[]> {
    if (!text) return []

    try {
      // Get all keywords
      const keywords = await this.getAllKeywords()

      // Convert text to lowercase for case-insensitive matching
      const lowerText = text.toLowerCase()

      // Find matching tag IDs
      const matchingTagIds = new Set<string>()

      keywords.forEach((kw) => {
        if (lowerText.includes(kw.keyword)) {
          matchingTagIds.add(kw.tag_id)
        }
      })

      return Array.from(matchingTagIds)
    } catch (err) {
      console.error("Error finding matching tags:", err)
      return []
    }
  },

  /**
   * Bulk assigns tags to a task
   * @param taskId The task ID
   * @param tagIds Array of tag IDs to assign
   * @returns Boolean indicating success
   */
  async assignTagsToTask(taskId: string, tagIds: string[]): Promise<boolean> {
    if (!taskId || !tagIds.length) return false

    try {
      // First, remove existing task-tag associations
      const { error: deleteError } = await supabaseClient.from("task_tags").delete().eq("task_id", taskId)

      if (deleteError) throw deleteError

      // Then add the new associations
      const taskTags = tagIds.map((tagId) => ({
        task_id: taskId,
        tag_id: tagId,
      }))

      const { error: insertError } = await supabaseClient.from("task_tags").insert(taskTags)

      if (insertError) throw insertError

      return true
    } catch (err) {
      console.error("Error assigning tags to task:", err)
      return false
    }
  },
}

