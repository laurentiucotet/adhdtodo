import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createServerClient } from "@supabase/ssr"

export async function middleware(request: NextRequest) {
  console.log("All cookies:", request.cookies.getAll())

  const response = NextResponse.next()

  try {
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get: (name) => request.cookies.get(name)?.value,
          set: (name, value, options) => response.cookies.set({ name, value, ...options }),
          remove: (name, options) => response.cookies.set({ name, value: "", ...options, maxAge: 0 }),
        },
      }
    )

    const { data, error } = await supabase.auth.getSession()

    console.log("Session data:", data)
    console.log("Session error:", error)

    const isAuthenticated = !!data.session
    const isProtectedRoute = request.nextUrl.pathname.startsWith("/dashboard")
    const isAuthPage = ["/login", "/signup"].includes(request.nextUrl.pathname)

    // 🔥 Fix: Preserve existing `redirect` param if already in URL
    const currentRedirect = request.nextUrl.searchParams.get("redirect") || request.nextUrl.pathname

    if (!isAuthenticated && isProtectedRoute) {
      console.log("No session, redirecting to login")
      const redirectUrl = new URL("/login", request.url)
      redirectUrl.searchParams.set("redirect", currentRedirect)
      return NextResponse.redirect(redirectUrl)
    }

    if (isAuthenticated && isAuthPage) {
      console.log("Has session, redirecting to dashboard")
      return NextResponse.redirect(new URL("/dashboard", request.url))
    }

    return response
  } catch (e) {
    console.error("Middleware error:", e)
    return response
  }
}

export const config = {
  matcher: ["/dashboard/:path*", "/login", "/signup"],
}

