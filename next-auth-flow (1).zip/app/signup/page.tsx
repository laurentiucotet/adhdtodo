import { SignupForm } from "@/components/signup-form"
import { TopNavigation } from "@/components/top-navigation"
import Link from "next/link"

export default function SignupPage() {
  return (
    <div className="min-h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold">Create an account</h1>
            <p className="text-muted-foreground mt-2">Sign up to get started with our platform</p>
          </div>
          <SignupForm />
          <div className="text-center text-sm">
            <p>
              Already have an account?{" "}
              <Link href="/login" className="font-medium text-primary hover:underline">
                Login
              </Link>
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}

