"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"

export default function Settings() {
  const { user, logout } = useAuth()
  const router = useRouter()

  const handleLogout = async () => {
    await logout()
    router.push("/")
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings</p>
      </div>
      <div className="grid gap-6">
        <Card className="rounded-2xl border-primary/10 overflow-hidden">
          <CardHeader className="bg-primary/5">
            <CardTitle className="text-primary">Account Information</CardTitle>
            <CardDescription>View your account details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div>
              <p className="text-sm font-medium">Name</p>
              <p className="text-sm text-muted-foreground">{user?.user_metadata?.name || "Not provided"}</p>
            </div>
            <div>
              <p className="text-sm font-medium">Email</p>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
            <div>
              <p className="text-sm font-medium">Account Created</p>
              <p className="text-sm text-muted-foreground">{new Date(user?.created_at || "").toLocaleDateString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-primary/10 overflow-hidden">
          <CardHeader className="bg-primary/5">
            <CardTitle className="text-primary">Session</CardTitle>
            <CardDescription>Manage your active session</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <p className="text-sm">You are currently logged in.</p>
          </CardContent>
          <CardFooter>
            <Button variant="destructive" onClick={handleLogout}>
              Logout
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

