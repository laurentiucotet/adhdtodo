"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PlusCircle, Loader2, Filter, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { TagSelectDialog } from "@/components/tag-select-dialog"
import { TagFilterChips } from "@/components/tag-filter-chips"
import { ActiveFiltersBar } from "@/components/active-filters-bar"
import { VirtualizedTaskList } from "@/components/virtualized-task-list"
import { TaskItem } from "@/components/task-item"
import { useAuth } from "@/hooks/use-auth"
import { useOptimisticTasks } from "@/hooks/use-optimistic-tasks"
import { useServerFilteredTasks } from "@/hooks/use-server-filtered-tasks"

export default function AllTasksPage() {
  const { user } = useAuth()
  const [newTask, setNewTask] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [tagDialogOpen, setTagDialogOpen] = useState(false)
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null)
  const [showFilters, setShowFilters] = useState(false)
  const [retryCount, setRetryCount] = useState(0)

  // Use the optimized server filtered tasks hook
  const {
    tasks,
    totalCount,
    loading,
    error,
    selectedTagIds,
    showCompleted,
    selectTag,
    deselectTag,
    clearAllTags,
    toggleShowCompleted,
    loadMore,
    hasMore,
    refreshTasks,
    getTaskTags,
    getTagData,
  } = useServerFilteredTasks({
    initialShowCompleted: true,
    pageSize: 20,
    // Only fetch the fields we need for the initial view
    initialFields: ["id", "text", "completed", "created_at"],
  })

  // Get optimistic task operations
  const { addTask, toggleTaskCompletion, updateTask, deleteTask, updateTaskTags } = useOptimisticTasks()

  // Add a new task
  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newTask.trim() === "" || !user) return

    setIsSubmitting(true)
    try {
      await addTask(newTask)
      setNewTask("") // Clear the input field
      refreshTasks(true) // Refresh tasks to include the new one
    } catch (err) {
      console.error("Error adding task:", err)
    } finally {
      setIsSubmitting(false)
    }
  }

  // Open tag dialog for a task
  const openTagDialog = (taskId: string) => {
    setSelectedTaskId(taskId)
    setTagDialogOpen(true)
  }

  // Retry loading if there was an error
  const handleRetry = () => {
    setRetryCount((prev) => prev + 1)
    refreshTasks(true)
  }

  // Force refresh when retry count changes
  useEffect(() => {
    if (retryCount > 0) {
      refreshTasks(true)
    }
  }, [retryCount, refreshTasks])

  // Ensure tasks is always an array
  const safeTasks = Array.isArray(tasks) ? tasks : []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">All Tasks</h1>
        <p className="text-muted-foreground">View and manage all your tasks</p>
      </div>

      <Card className="rounded-2xl border-primary/10 overflow-hidden">
        <CardHeader className="bg-primary/5">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-primary">Task List</CardTitle>
              <CardDescription>All your tasks in one place</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-1"
              >
                <Filter className="h-4 w-4" />
                <span>Filters</span>
                {selectedTagIds.length > 0 && (
                  <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                    {selectedTagIds.length}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-6 space-y-4">
          {/* Task input form */}
          <form onSubmit={handleAddTask} className="flex gap-2">
            <Input
              placeholder="Add a new task..."
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              className="rounded-xl flex-1"
              disabled={isSubmitting}
            />
            <Button
              type="submit"
              size="sm"
              className="flex items-center gap-1"
              disabled={isSubmitting || newTask.trim() === ""}
            >
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlusCircle className="h-4 w-4" />}
              <span>Add</span>
            </Button>
          </form>

          {/* Tag filters */}
          {showFilters && (
            <div className="border rounded-xl p-3 bg-muted/10">
              <TagFilterChips
                selectedTagIds={selectedTagIds}
                onTagSelect={selectTag}
                onTagDeselect={deselectTag}
                onClearAll={clearAllTags}
              />
            </div>
          )}

          {/* Active filters bar */}
          <ActiveFiltersBar selectedTagIds={selectedTagIds} onTagDeselect={deselectTag} onClearAll={clearAllTags} />

          {/* Error message */}
          {error && (
            <Alert variant="destructive" className="rounded-xl">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="flex items-center justify-between">
                <span>{error}</span>
                <Button variant="outline" size="sm" onClick={handleRetry}>
                  Retry
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {/* Virtualized task list */}
          <div className="min-h-[400px]">
            <VirtualizedTaskList
              tasks={safeTasks}
              loading={loading}
              hasMore={hasMore}
              onLoadMore={loadMore}
              emptyMessage={
                selectedTagIds.length > 0
                  ? "No tasks match your current filters."
                  : "No tasks available. Add some tasks to get started."
              }
              renderItem={(task, style) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  style={style}
                  onToggleCompletion={toggleTaskCompletion}
                  onUpdateTask={updateTask}
                  onDeleteTask={deleteTask}
                  onOpenTagDialog={openTagDialog}
                  onTagClick={selectTag}
                  getTaskTags={getTaskTags}
                  getTagData={getTagData}
                />
              )}
            />
          </div>
        </CardContent>

        {safeTasks.length > 0 && (
          <CardFooter className="border-t bg-muted/10 flex justify-between items-center py-3">
            <div className="text-sm text-muted-foreground">
              {safeTasks.length} of {totalCount} task{totalCount !== 1 ? "s" : ""}
            </div>
            <Button variant="ghost" size="sm" onClick={toggleShowCompleted} className="text-xs">
              {showCompleted ? "Hide completed tasks" : "Show completed tasks"}
            </Button>
          </CardFooter>
        )}
      </Card>

      {/* Tag selection dialog */}
      {selectedTaskId && (
        <TagSelectDialog
          taskId={selectedTaskId}
          isOpen={tagDialogOpen}
          onClose={() => {
            setTagDialogOpen(false)
            setSelectedTaskId(null)
            refreshTasks() // Refresh tasks to update tags
          }}
          onSave={(tagIds) => {
            updateTaskTags(selectedTaskId, tagIds)
          }}
        />
      )}
    </div>
  )
}

