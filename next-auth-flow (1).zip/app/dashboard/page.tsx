"use client"

import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Dashboard() {
  const { user } = useAuth()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back, {user?.user_metadata?.name || user?.email || "User"}!</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="rounded-2xl border-primary/10 overflow-hidden">
          <CardHeader className="pb-2 bg-primary/5">
            <CardTitle className="text-primary">Account Info</CardTitle>
            <CardDescription>Your account details</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">Email:</span>
                <span>{user?.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">User ID:</span>
                <span className="truncate max-w-[180px]">{user?.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Last Sign In:</span>
                <span>{new Date(user?.last_sign_in_at || "").toLocaleDateString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-primary/10 overflow-hidden">
          <CardHeader className="pb-2 bg-primary/5">
            <CardTitle className="text-primary">Activity</CardTitle>
            <CardDescription>Your recent activity</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <p>No recent activity to display.</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-primary/10 overflow-hidden">
          <CardHeader className="pb-2 bg-primary/5">
            <CardTitle className="text-primary">Stats</CardTitle>
            <CardDescription>Your usage statistics</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <p>No statistics available yet.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

