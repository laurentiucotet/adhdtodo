"use client"

import type React from "react"

import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { TopNavigation } from "@/components/top-navigation"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
  if (!isLoading && !user) {
    const currentPath = encodeURIComponent(window.location.pathname)
    router.push(`/login?redirect=${currentPath}`)
  }
}, [user, isLoading, router])

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex min-h-full items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  // If not authenticated and not loading, the useEffect will redirect
  if (!user) {
    return null
  }

  return (
    <div className="min-h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 p-6">{children}</main>
    </div>
  )
}

