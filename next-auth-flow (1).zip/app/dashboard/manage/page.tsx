"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TagManagement } from "@/components/tag-management"
import { AutoTaggingInfo } from "@/components/auto-tagging-info"
import { TagStatistics } from "@/components/tag-statistics"

export default function ManagePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">Manage</h1>
        <p className="text-muted-foreground">Manage your tasks, tags, and lists</p>
      </div>

      <TagManagement />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <AutoTaggingInfo />
        <TagStatistics />
      </div>

      <Card className="rounded-2xl border-primary/10 overflow-hidden">
        <CardHeader className="bg-primary/5">
          <CardTitle className="text-primary">Task Management</CardTitle>
          <CardDescription>Configure your task settings</CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <p>Additional management options will appear here.</p>
        </CardContent>
      </Card>
    </div>
  )
}

