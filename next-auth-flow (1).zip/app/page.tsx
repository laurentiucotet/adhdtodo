import Link from "next/link"
import { Button } from "@/components/ui/button"
import { TopNavigation } from "@/components/top-navigation"

export default function Home() {
  return (
    <div className="min-h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-24 bg-gradient-to-b from-background to-secondary/30">
        <div className="max-w-3xl w-full text-center space-y-8">
          <h1 className="text-4xl font-bold tracking-tight text-primary">Welcome to Our Platform</h1>
          <p className="text-xl text-muted-foreground">A minimal Next.js application with authentication flow</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg">
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild variant="soft" size="lg">
              <Link href="/signup">Sign Up</Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

