import Link from "next/link"
import { TopNavigation } from "@/components/top-navigation"
import { LoginForm } from "@/components/login-form"

export default function LoginPage({
  searchParams,
}: {
  searchParams: { redirect?: string }
}) {
  const redirectPath = searchParams.redirect || "/dashboard"

  return (
    <div className="min-h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold">Login to your account</h1>
            <p className="text-muted-foreground mt-2">Enter your credentials to access your account</p>
          </div>
          <LoginForm redirectPath={redirectPath} />
          <div className="text-center text-sm">
            <p>
              Don&apos;t have an account?{" "}
              <Link href="/signup" className="font-medium text-primary hover:underline">
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}

