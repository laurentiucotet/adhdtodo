"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { supabaseClient } from "@/utils/supabase/client"
import { TagService } from "@/services/tag-service"

export interface Tag {
  id: string
  name: string
  color: string
  created_at: string
}

export function useTags() {
  const [tags, setTags] = useState<Tag[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()

  // Fetch all tags for the current user
  const fetchTags = async () => {
    if (!user) return

    try {
      setLoading(true)
      setError(null)

      const tagsData = await TagService.getAllTags(user.id)
      setTags(tagsData)
    } catch (err) {
      console.error("Error fetching tags:", err)
      setError("Failed to load tags")
    } finally {
      setLoading(false)
    }
  }

  // Add a new tag
  const addTag = async (name: string, color: string) => {
    if (!user || !name.trim()) return null

    try {
      const newTag = await TagService.createTag(user.id, name, color)

      if (newTag) {
        setTags((prevTags) => [...prevTags, newTag].sort((a, b) => a.name.localeCompare(b.name)))
      }

      return newTag
    } catch (err) {
      console.error("Error adding tag:", err)
      setError("Failed to add tag")
      return null
    }
  }

  // Update a tag
  const updateTag = async (id: string, updates: { name?: string; color?: string }) => {
    if (!user) return false

    try {
      const success = await TagService.updateTag(id, updates)

      if (success) {
        setTags((prevTags) =>
          prevTags
            .map((tag) => (tag.id === id ? { ...tag, ...updates } : tag))
            .sort((a, b) => a.name.localeCompare(b.name)),
        )
      }

      return success
    } catch (err) {
      console.error('Error updating tag:", err)Error("Failed to update tag')
      return false
    }
  }

  // Delete a tag
  const deleteTag = async (id: string) => {
    if (!user) return false

    try {
      const success = await TagService.deleteTag(id)

      if (success) {
        setTags((prevTags) => prevTags.filter((tag) => tag.id !== id))
      }

      return success
    } catch (err) {
      console.error("Error deleting tag:", err)
      setError("Failed to delete tag")
      return false
    }
  }

  // Get task tags
  const getTaskTags = async (taskId: string) => {
    if (!user) return []

    try {
      return await TagService.getTaskTags(taskId)
    } catch (err) {
      console.error("Error fetching task tags:", err)
      return []
    }
  }

  // Update task tags
  const updateTaskTags = async (taskId: string, tagIds: string[]) => {
    if (!user) return false

    try {
      return await TagService.assignTagsToTask(taskId, tagIds)
    } catch (err) {
      console.error("Error updating task tags:", err)
      return false
    }
  }

  // Set up real-time subscription for tags
  useEffect(() => {
    if (!user) {
      setTags([])
      setLoading(false)
      return
    }

    fetchTags()

    // Set up real-time subscription
    const subscription = supabaseClient
      .channel("tags-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "tags",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            setTags((prevTags) => {
              if (!prevTags.some((tag) => tag.id === payload.new.id)) {
                return [...prevTags, payload.new].sort((a, b) => a.name.localeCompare(b.name))
              }
              return prevTags
            })
          } else if (payload.eventType === "UPDATE") {
            setTags((prevTags) =>
              prevTags
                .map((tag) => (tag.id === payload.new.id ? payload.new : tag))
                .sort((a, b) => a.name.localeCompare(b.name)),
            )
          } else if (payload.eventType === "DELETE") {
            setTags((prevTags) => prevTags.filter((tag) => tag.id !== payload.old.id))
          }
        },
      )
      .subscribe()

    return () => {
      subscription.unsubscribe()
    }
  }, [user])

  return {
    tags,
    loading,
    error,
    addTag,
    updateTag,
    deleteTag,
    getTaskTags,
    updateTaskTags,
    refreshTags: fetchTags,
  }
}

