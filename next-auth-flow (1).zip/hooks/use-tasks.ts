"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { supabaseClient } from "@/utils/supabase/client"
import { TaskService } from "@/services/task-service"
import type { Task } from "@/types"

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()

  // Fetch all tasks for the current user
  const fetchTasks = async () => {
    if (!user) return

    try {
      setLoading(true)
      setError(null)

      const tasksData = await TaskService.getAllTasks(user.id)
      setTasks(tasksData)
    } catch (err) {
      console.error("Error fetching tasks:", err)
      setError("Failed to load tasks")
    } finally {
      setLoading(false)
    }
  }

  // Add a new task
  const addTask = async (text: string) => {
    if (!user || !text.trim()) return null

    try {
      const newTask = await TaskService.createTask(user.id, text)

      if (newTask) {
        setTasks((prevTasks) => [newTask, ...prevTasks])
      }

      return newTask
    } catch (err) {
      console.error("Error adding task:", err)
      setError("Failed to add task")
      return null
    }
  }

  // Update a task
  const updateTask = async (id: string, updates: Partial<Omit<Task, "id" | "created_at" | "updated_at">>) => {
    if (!user) return false

    try {
      const success = await TaskService.updateTask(id, updates)

      if (success) {
        setTasks((prevTasks) => prevTasks.map((task) => (task.id === id ? { ...task, ...updates } : task)))
      }

      return success
    } catch (err) {
      console.error("Error updating task:", err)
      setError("Failed to update task")
      return false
    }
  }

  // Toggle task completion status
  const toggleTaskCompletion = async (id: string, currentStatus: boolean) => {
    return TaskService.toggleTaskCompletion(id, currentStatus)
  }

  // Delete a task
  const deleteTask = async (id: string) => {
    if (!user) return false

    try {
      const success = await TaskService.deleteTask(id)

      if (success) {
        setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id))
      }

      return success
    } catch (err) {
      console.error("Error deleting task:", err)
      setError("Failed to delete task")
      return false
    }
  }

  // Set up real-time subscription for tasks
  useEffect(() => {
    if (!user) {
      setTasks([])
      setLoading(false)
      return
    }

    fetchTasks()

    // Set up real-time subscription
    const subscription = supabaseClient
      .channel("tasks-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "tasks",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            // Only add if not already in the list (to prevent duplicates)
            setTasks((prevTasks) => {
              if (!prevTasks.some((task) => task.id === payload.new.id)) {
                return [payload.new, ...prevTasks]
              }
              return prevTasks
            })
          } else if (payload.eventType === "UPDATE") {
            setTasks((prevTasks) => prevTasks.map((task) => (task.id === payload.new.id ? payload.new : task)))
          } else if (payload.eventType === "DELETE") {
            setTasks((prevTasks) => prevTasks.filter((task) => task.id !== payload.old.id))
          }
        },
      )
      .subscribe()

    return () => {
      subscription.unsubscribe()
    }
  }, [user])

  return {
    tasks,
    loading,
    error,
    addTask,
    updateTask,
    toggleTaskCompletion,
    deleteTask,
    refreshTasks: fetchTasks,
  }
}

