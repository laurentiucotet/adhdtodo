"use client"

import { useState, useEffect } from "react"
import { supabaseClient } from "@/utils/supabase/client"
import type { Tag } from "@/hooks/use-tags"

export interface TaskTag {
  task_id: string
  tag_id: string
  tag?: Tag
}

export function useTaskTags(taskId: string) {
  const [taskTags, setTaskTags] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Fetch tags for a specific task
  const fetchTaskTags = async () => {
    if (!taskId) {
      setTaskTags([])
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      const { data, error } = await supabaseClient.from("task_tags").select("tag_id").eq("task_id", taskId)

      if (error) {
        throw error
      }

      setTaskTags(data.map((item) => item.tag_id))
    } catch (err) {
      console.error("Error fetching task tags:", err)
      setError("Failed to load task tags")
    } finally {
      setLoading(false)
    }
  }

  // Update tags for a task
  const updateTaskTags = async (tagIds: string[]) => {
    if (!taskId) return false

    try {
      // First, remove all existing tags for this task
      const { error: deleteError } = await supabaseClient.from("task_tags").delete().eq("task_id", taskId)

      if (deleteError) {
        throw deleteError
      }

      // Then, add the new tags
      if (tagIds.length > 0) {
        const newTaskTags = tagIds.map((tagId) => ({
          task_id: taskId,
          tag_id: tagId,
        }))

        const { error: insertError } = await supabaseClient.from("task_tags").insert(newTaskTags)

        if (insertError) {
          throw insertError
        }
      }

      setTaskTags(tagIds)
      return true
    } catch (err) {
      console.error("Error updating task tags:", err)
      setError("Failed to update task tags")
      return false
    }
  }

  // Set up initial fetch and real-time subscription
  useEffect(() => {
    fetchTaskTags()

    // Set up real-time subscription for task tags
    if (taskId) {
      const subscription = supabaseClient
        .channel(`task-tags-${taskId}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "task_tags",
            filter: `task_id=eq.${taskId}`,
          },
          () => {
            fetchTaskTags()
          },
        )
        .subscribe()

      return () => {
        subscription.unsubscribe()
      }
    }
  }, [taskId])

  return {
    taskTags,
    loading,
    error,
    updateTaskTags,
    refreshTaskTags: fetchTaskTags,
  }
}

