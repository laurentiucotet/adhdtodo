"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { useAuth } from "@/hooks/use-auth"
import { FilteredTasksService } from "@/services/filtered-tasks-service"
import type { Task } from "@/types"

interface ServerFilteredTasksOptions {
  initialShowCompleted?: boolean
  pageSize?: number
  initialFields?: string[]
}

export function useServerFilteredTasks(options: ServerFilteredTasksOptions = {}) {
  const {
    initialShowCompleted = true,
    pageSize = 20,
    initialFields = ["id", "text", "completed", "created_at", "updated_at"],
  } = options

  const { user } = useAuth()
  const [tasks, setTasks] = useState<Task[]>([])
  const [totalCount, setTotalCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>([])
  const [showCompleted, setShowCompleted] = useState(initialShowCompleted)

  // Cache for task tags and tag data
  const taskTagsCache = useRef<Record<string, string[]>>({})
  const tagDataCache = useRef<Record<string, { id: string; name: string; color: string }>>({})

  // Track if component is mounted
  const isMounted = useRef(true)

  // Track if we're currently fetching to prevent duplicate requests
  const isFetching = useRef(false)

  // Track if initial fetch has been done
  const initialFetchDone = useRef(false)

  // Track the last filter state to prevent unnecessary fetches
  const lastFetchParams = useRef({
    userId: "",
    showCompleted: initialShowCompleted,
    selectedTagIds: [] as string[],
  })

  // Cleanup on unmount
  useEffect(() => {
    isMounted.current = true
    return () => {
      isMounted.current = false
    }
  }, [])

  // Fetch tasks with the current filters
  const fetchTasks = useCallback(
    async (refresh = false) => {
      // Don't fetch if no user or already fetching
      if (!user || isFetching.current) return

      // Create current params object for comparison
      const currentParams = {
        userId: user.id,
        showCompleted,
        selectedTagIds: [...selectedTagIds].sort().join(","),
      }

      // Create last params object for comparison
      const lastParams = {
        userId: lastFetchParams.current.userId,
        showCompleted: lastFetchParams.current.showCompleted,
        selectedTagIds: [...lastFetchParams.current.selectedTagIds].sort().join(","),
      }

      // Skip fetch if parameters haven't changed and it's not a forced refresh
      if (
        !refresh &&
        initialFetchDone.current &&
        currentParams.userId === lastParams.userId &&
        currentParams.showCompleted === lastParams.showCompleted &&
        currentParams.selectedTagIds === lastParams.selectedTagIds
      ) {
        return
      }

      // Update last fetch parameters
      lastFetchParams.current = {
        userId: user.id,
        showCompleted,
        selectedTagIds: [...selectedTagIds],
      }

      try {
        // Set fetching flag to prevent duplicate requests
        isFetching.current = true

        if (refresh) {
          setLoading(true)
          setTasks([])
        } else {
          setLoadingMore(true)
        }

        setError(null)

        const cursor = refresh ? null : nextCursor

        console.log("Fetching tasks with params:", {
          userId: user.id,
          completed: showCompleted ? undefined : false,
          tagIds: selectedTagIds.length > 0 ? selectedTagIds : undefined,
          cursor: cursor || undefined,
        })

        const {
          tasks: newTasks,
          nextCursor: newCursor,
          count,
        } = await FilteredTasksService.getFilteredTasks({
          userId: user.id,
          completed: showCompleted ? undefined : false,
          tagIds: selectedTagIds.length > 0 ? selectedTagIds : undefined,
          limit: pageSize,
          cursor: cursor || undefined,
          fields: initialFields,
        })

        console.log("Fetched tasks:", newTasks?.length || 0, "Next cursor:", newCursor, "Count:", count)

        if (isMounted.current) {
          // Ensure newTasks is an array
          const safeNewTasks = Array.isArray(newTasks) ? newTasks : []

          if (refresh) {
            setTasks(safeNewTasks)
          } else {
            setTasks((prev) => [...(Array.isArray(prev) ? prev : []), ...safeNewTasks])
          }

          setNextCursor(newCursor)
          setTotalCount(count)

          // Mark initial fetch as done
          initialFetchDone.current = true
        }
      } catch (err) {
        console.error("Error fetching tasks:", err)
        if (isMounted.current) {
          setError("Failed to load tasks. Please try again.")
        }
      } finally {
        if (isMounted.current) {
          setLoading(false)
          setLoadingMore(false)
        }
        // Reset fetching flag
        isFetching.current = false
      }
    },
    [user, showCompleted, selectedTagIds, nextCursor, pageSize, initialFields],
  )

  // Initial fetch when component mounts or user changes
  useEffect(() => {
    // Only fetch if we have a user and haven't done the initial fetch yet
    if (user && !initialFetchDone.current && !isFetching.current) {
      fetchTasks(true)
    }
  }, [user, fetchTasks])

  // Handle filter changes
  useEffect(() => {
    // Skip if initial fetch hasn't been done or we're already fetching
    if (user && initialFetchDone.current && !isFetching.current) {
      // Create current params object for comparison
      const currentParams = {
        userId: user.id,
        showCompleted,
        selectedTagIds: [...selectedTagIds].sort().join(","),
      }

      // Create last params object for comparison
      const lastParams = {
        userId: lastFetchParams.current.userId,
        showCompleted: lastFetchParams.current.showCompleted,
        selectedTagIds: [...lastFetchParams.current.selectedTagIds].sort().join(","),
      }

      // Only fetch if parameters have changed
      if (
        currentParams.showCompleted !== lastParams.showCompleted ||
        currentParams.selectedTagIds !== lastParams.selectedTagIds
      ) {
        fetchTasks(true)
      }
    }
  }, [user, showCompleted, selectedTagIds, fetchTasks])

  // Get tags for a specific task
  const getTaskTags = useCallback(async (taskId: string): Promise<string[]> => {
    if (!taskId) return []

    // Return from cache if available
    if (taskTagsCache.current[taskId]) {
      return taskTagsCache.current[taskId]
    }

    try {
      const taskTagsMap = await FilteredTasksService.lazyLoadTaskTags([taskId])
      const tags = taskTagsMap[taskId] || []

      // Update cache
      taskTagsCache.current[taskId] = tags

      return tags
    } catch (err) {
      console.error(`Error fetching tags for task ${taskId}:`, err)
      return []
    }
  }, [])

  // Get tag data for display
  const getTagData = useCallback(async (tagId: string): Promise<{ id: string; name: string; color: string } | null> => {
    if (!tagId) return null

    // Return from cache if available
    if (tagDataCache.current[tagId]) {
      return tagDataCache.current[tagId]
    }

    try {
      const tagData = await FilteredTasksService.getMinimalTagData([tagId])

      if (tagData && tagData.length > 0) {
        // Update cache
        tagDataCache.current[tagId] = tagData[0]
        return tagData[0]
      }

      return null
    } catch (err) {
      console.error(`Error fetching data for tag ${tagId}:`, err)
      return null
    }
  }, [])

  // Load more tasks
  const loadMore = useCallback(() => {
    if (nextCursor && !loading && !loadingMore && !isFetching.current) {
      fetchTasks(false)
    }
  }, [nextCursor, loading, loadingMore, fetchTasks])

  // Refresh tasks
  const refreshTasks = useCallback(
    (resetCursor = false) => {
      if (!isFetching.current) {
        fetchTasks(resetCursor)
      }
    },
    [fetchTasks],
  )

  // Tag selection handlers
  const selectTag = useCallback((tagId: string) => {
    setSelectedTagIds((prev) => {
      if (prev.includes(tagId)) return prev
      return [...prev, tagId]
    })
  }, [])

  const deselectTag = useCallback((tagId: string) => {
    setSelectedTagIds((prev) => prev.filter((id) => id !== tagId))
  }, [])

  const clearAllTags = useCallback(() => {
    setSelectedTagIds([])
  }, [])

  // Toggle showing completed tasks
  const toggleShowCompleted = useCallback(() => {
    setShowCompleted((prev) => !prev)
  }, [])

  return {
    tasks: Array.isArray(tasks) ? tasks : [],
    totalCount,
    loading,
    loadingMore,
    error,
    selectedTagIds,
    showCompleted,
    selectTag,
    deselectTag,
    clearAllTags,
    toggleShowCompleted,
    loadMore,
    hasMore: !!nextCursor,
    refreshTasks,
    getTaskTags,
    getTagData,
  }
}

