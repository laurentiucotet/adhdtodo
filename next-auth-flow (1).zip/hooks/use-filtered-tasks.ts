"use client"

import { useState, useEffect, useMemo } from "react"
import type { Task } from "@/types"
import { supabaseClient } from "@/utils/supabase/client"

export function useFilteredTasks(tasks: Task[], showCompleted = true) {
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>([])
  const [taskTagMap, setTaskTagMap] = useState<Record<string, string[]>>({})
  const [isLoading, setIsLoading] = useState(false)

  // Fetch all task-tag relationships once
  useEffect(() => {
    const fetchTaskTags = async () => {
      if (!tasks.length) return

      setIsLoading(true)
      try {
        const taskIds = tasks.map((task) => task.id)

        const { data, error } = await supabaseClient.from("task_tags").select("task_id, tag_id").in("task_id", taskIds)

        if (error) throw error

        // Create a map of task_id -> tag_ids[]
        const tagMap: Record<string, string[]> = {}

        data.forEach((item) => {
          if (!tagMap[item.task_id]) {
            tagMap[item.task_id] = []
          }
          tagMap[item.task_id].push(item.tag_id)
        })

        setTaskTagMap(tagMap)
      } catch (err) {
        console.error("Error fetching task tags:", err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchTaskTags()
  }, [tasks])

  // Filter tasks based on selected tags and completion status
  const filteredTasks = useMemo(() => {
    // First filter by completion status
    let filtered = showCompleted ? tasks : tasks.filter((task) => !task.completed)

    // Then filter by selected tags if any are selected
    if (selectedTagIds.length > 0) {
      filtered = filtered.filter((task) => {
        const taskTags = taskTagMap[task.id] || []
        // Check if the task has at least one of the selected tags
        return selectedTagIds.some((tagId) => taskTags.includes(tagId))
      })
    }

    return filtered
  }, [tasks, showCompleted, selectedTagIds, taskTagMap])

  // Tag selection handlers
  const selectTag = (tagId: string) => {
    setSelectedTagIds((prev) => [...prev, tagId])
  }

  const deselectTag = (tagId: string) => {
    setSelectedTagIds((prev) => prev.filter((id) => id !== tagId))
  }

  const clearAllTags = () => {
    setSelectedTagIds([])
  }

  return {
    filteredTasks,
    selectedTagIds,
    selectTag,
    deselectTag,
    clearAllTags,
    isFilterLoading: isLoading,
  }
}

