"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { supabaseClient } from "@/utils/supabase/client"
import { TagKeywordsService } from "@/services/tag-keywords-service"

export interface TagKeyword {
  id: string
  tag_id: string
  keyword: string
  created_at: string
}

export function useTagKeywords(tagId?: string) {
  const [keywords, setKeywords] = useState<TagKeyword[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()

  // Fetch keywords for a specific tag or all keywords
  const fetchKeywords = async () => {
    if (!user) return

    try {
      setLoading(true)
      setError(null)

      let keywordsData: TagKeyword[] = []

      if (tagId) {
        keywordsData = await TagKeywordsService.getKeywordsByTagId(tagId)
      } else {
        keywordsData = await TagKeywordsService.getAllKeywords()
      }

      setKeywords(keywordsData)
    } catch (err) {
      console.error("Error fetching tag keywords:", err)
      setError("Failed to load keywords")
    } finally {
      setLoading(false)
    }
  }

  // Add a new keyword to a tag
  const addKeyword = async (tagId: string, keyword: string) => {
    if (!user || !keyword.trim()) return null

    try {
      const newKeyword = await TagKeywordsService.addKeyword(tagId, keyword)

      if (newKeyword) {
        setKeywords((prevKeywords) => [...prevKeywords, newKeyword].sort((a, b) => a.keyword.localeCompare(b.keyword)))
      }

      return newKeyword
    } catch (err) {
      console.error("Error adding keyword:", err)
      setError("Failed to add keyword")
      return null
    }
  }

  // Update a keyword
  const updateKeyword = async (id: string, newKeyword: string) => {
    if (!user || !newKeyword.trim()) return false

    try {
      const success = await TagKeywordsService.updateKeyword(id, newKeyword)

      if (success) {
        setKeywords((prevKeywords) =>
          prevKeywords
            .map((kw) => (kw.id === id ? { ...kw, keyword: newKeyword.trim().toLowerCase() } : kw))
            .sort((a, b) => a.keyword.localeCompare(b.keyword)),
        )
      }

      return success
    } catch (err) {
      console.error("Error updating keyword:", err)
      setError("Failed to update keyword")
      return false
    }
  }

  // Delete a keyword
  const deleteKeyword = async (id: string) => {
    if (!user) return false

    try {
      const success = await TagKeywordsService.deleteKeyword(id)

      if (success) {
        setKeywords((prevKeywords) => prevKeywords.filter((kw) => kw.id !== id))
      }

      return success
    } catch (err) {
      console.error("Error deleting keyword:", err)
      setError("Failed to delete keyword")
      return false
    }
  }

  // Find matching tags for a text
  const findMatchingTags = async (text: string): Promise<string[]> => {
    if (!user || !text) return []

    try {
      return TagKeywordsService.findMatchingTags(text)
    } catch (err) {
      console.error("Error finding matching tags:", err)
      return []
    }
  }

  // Set up real-time subscription for keywords
  useEffect(() => {
    if (!user) {
      setKeywords([])
      setLoading(false)
      return
    }

    fetchKeywords()

    // Set up real-time subscription
    let subscription

    if (tagId) {
      // Subscribe to changes for a specific tag
      subscription = supabaseClient
        .channel(`tag-keywords-${tagId}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "tag_keywords",
            filter: `tag_id=eq.${tagId}`,
          },
          (payload) => {
            if (payload.eventType === "INSERT") {
              setKeywords((prevKeywords) => {
                if (!prevKeywords.some((kw) => kw.id === payload.new.id)) {
                  return [...prevKeywords, payload.new].sort((a, b) => a.keyword.localeCompare(b.keyword))
                }
                return prevKeywords
              })
            } else if (payload.eventType === "UPDATE") {
              setKeywords((prevKeywords) =>
                prevKeywords
                  .map((kw) => (kw.id === payload.new.id ? payload.new : kw))
                  .sort((a, b) => a.keyword.localeCompare(b.keyword)),
              )
            } else if (payload.eventType === "DELETE") {
              setKeywords((prevKeywords) => prevKeywords.filter((kw) => kw.id !== payload.old.id))
            }
          },
        )
        .subscribe()
    } else {
      // Subscribe to all keyword changes
      subscription = supabaseClient
        .channel("all-tag-keywords")
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "tag_keywords",
          },
          () => {
            // Just refresh all keywords on any change
            fetchKeywords()
          },
        )
        .subscribe()
    }

    return () => {
      subscription?.unsubscribe()
    }
  }, [user, tagId])

  return {
    keywords,
    loading,
    error,
    addKeyword,
    updateKeyword,
    deleteKeyword,
    findMatchingTags,
    refreshKeywords: fetchKeywords,
  }
}

