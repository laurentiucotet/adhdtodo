"use client"

import { useState, useCallback } from "react"
import { useNormalizedStore } from "@/store/normalized-store"
import { TaskService } from "@/services/task-service"
import { useAuth } from "@/hooks/use-auth"
import { v4 as uuidv4 } from "uuid"
import type { Task } from "@/types"

export function useOptimisticTasks() {
  const { user } = useAuth()
  // Initialize pendingOperations as an empty object
  const [pendingOperations, setPendingOperations] = useState<Record<string, { type: string; data: any }>>({})

  const { tasks, taskIds, addTask, updateTask, removeTask, toggleTaskCompletion, setTaskTags } = useNormalizedStore()

  // Helper to create a temporary task ID
  const createTempId = () => `temp-${uuidv4()}`

  // Add a task with optimistic update
  const addTaskOptimistic = useCallback(
    async (text: string) => {
      if (!user || !text.trim()) return null

      // Create a temporary ID for optimistic update
      const tempId = createTempId()

      // Create optimistic task
      const optimisticTask: Task = {
        id: tempId,
        text: text.trim(),
        completed: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      // Track pending operation
      setPendingOperations((prev) => ({
        ...prev,
        [tempId]: { type: "add", data: { text } },
      }))

      // Add to store optimistically
      addTask(optimisticTask)

      try {
        // Perform actual API call
        const newTask = await TaskService.createTask(user.id, text)

        if (newTask) {
          // Replace temporary task with real one
          addTask(newTask)
          removeTask(tempId)
        } else {
          // If API call failed, remove optimistic task
          removeTask(tempId)
        }

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [tempId]: removed, ...rest } = prev
          return rest
        })

        return newTask
      } catch (err) {
        console.error("Error adding task:", err)

        // Remove optimistic task on error
        removeTask(tempId)

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [tempId]: removed, ...rest } = prev
          return rest
        })

        return null
      }
    },
    [user, addTask, removeTask],
  )

  // Toggle task completion with optimistic update
  const toggleTaskCompletionOptimistic = useCallback(
    async (taskId: string) => {
      if (!tasks[taskId]) return false

      // Store original state for rollback
      const originalTask = { ...tasks[taskId] }

      // Track pending operation
      setPendingOperations((prev) => ({
        ...prev,
        [taskId]: { type: "toggle", data: { originalTask } },
      }))

      // Update optimistically
      toggleTaskCompletion(taskId)

      try {
        // Perform actual API call
        const success = await TaskService.toggleTaskCompletion(taskId, originalTask.completed)

        if (!success) {
          // Rollback on failure
          updateTask(taskId, originalTask)
        }

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [taskId]: removed, ...rest } = prev
          return rest
        })

        return success
      } catch (err) {
        console.error("Error toggling task completion:", err)

        // Rollback on error
        updateTask(taskId, originalTask)

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [taskId]: removed, ...rest } = prev
          return rest
        })

        return false
      }
    },
    [tasks, toggleTaskCompletion, updateTask],
  )

  // Update task with optimistic update
  const updateTaskOptimistic = useCallback(
    async (taskId: string, text: string) => {
      if (!tasks[taskId]) return false

      // Store original state for rollback
      const originalTask = { ...tasks[taskId] }

      // Track pending operation
      setPendingOperations((prev) => ({
        ...prev,
        [taskId]: { type: "update", data: { originalTask } },
      }))

      // Update optimistically
      updateTask(taskId, { text, updated_at: new Date().toISOString() })

      try {
        // Perform actual API call
        const success = await TaskService.updateTask(taskId, { text })

        if (!success) {
          // Rollback on failure
          updateTask(taskId, originalTask)
        }

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [taskId]: removed, ...rest } = prev
          return rest
        })

        return success
      } catch (err) {
        console.error("Error updating task:", err)

        // Rollback on error
        updateTask(taskId, originalTask)

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [taskId]: removed, ...rest } = prev
          return rest
        })

        return false
      }
    },
    [tasks, updateTask],
  )

  // Delete task with optimistic update
  const deleteTaskOptimistic = useCallback(
    async (taskId: string) => {
      if (!tasks[taskId]) return false

      // Store original state for rollback
      const originalTask = { ...tasks[taskId] }

      // Track pending operation
      setPendingOperations((prev) => ({
        ...prev,
        [taskId]: { type: "delete", data: { originalTask } },
      }))

      // Delete optimistically
      removeTask(taskId)

      try {
        // Perform actual API call
        const success = await TaskService.deleteTask(taskId)

        if (!success) {
          // Rollback on failure
          addTask(originalTask)
        }

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [taskId]: removed, ...rest } = prev
          return rest
        })

        return success
      } catch (err) {
        console.error("Error deleting task:", err)

        // Rollback on error
        addTask(originalTask)

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [taskId]: removed, ...rest } = prev
          return rest
        })

        return false
      }
    },
    [tasks, removeTask, addTask],
  )

  // Update task tags with optimistic update
  const updateTaskTagsOptimistic = useCallback(
    async (taskId: string, tagIds: string[]) => {
      // Store original tags for rollback
      const originalTagIds = useNormalizedStore.getState().taskTags[taskId] || []

      // Track pending operation
      setPendingOperations((prev) => ({
        ...prev,
        [`tags-${taskId}`]: { type: "updateTags", data: { originalTagIds } },
      }))

      // Update optimistically
      setTaskTags(taskId, tagIds)

      try {
        // Perform actual API call
        const success = await TaskService.updateTaskTags(taskId, tagIds)

        if (!success) {
          // Rollback on failure
          setTaskTags(taskId, originalTagIds)
        }

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [`tags-${taskId}`]: removed, ...rest } = prev
          return rest
        })

        return success
      } catch (err) {
        console.error("Error updating task tags:", err)

        // Rollback on error
        setTaskTags(taskId, originalTagIds)

        // Remove from pending operations
        setPendingOperations((prev) => {
          const { [`tags-${taskId}`]: removed, ...rest } = prev
          return rest
        })

        return false
      }
    },
    [setTaskTags],
  )

  // Get visible tasks based on filters
  const getVisibleTasks = useCallback(() => {
    const state = useNormalizedStore.getState()
    const { showCompleted, selectedTagIds } = state

    return taskIds
      .map((id) => tasks[id])
      .filter((task) => {
        // Filter by completion status
        if (!showCompleted && task.completed) {
          return false
        }

        // Filter by selected tags
        if (selectedTagIds.length > 0) {
          const taskTagIds = state.taskTags[task.id] || []
          return selectedTagIds.some((tagId) => taskTagIds.includes(tagId))
        }

        return true
      })
  }, [tasks, taskIds])

  return {
    tasks,
    taskIds,
    pendingOperations,
    addTask: addTaskOptimistic,
    toggleTaskCompletion: toggleTaskCompletionOptimistic,
    updateTask: updateTaskOptimistic,
    deleteTask: deleteTaskOptimistic,
    updateTaskTags: updateTaskTagsOptimistic,
    getVisibleTasks,
  }
}

